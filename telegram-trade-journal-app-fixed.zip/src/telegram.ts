// ─────────────────────────────────────────────────────────────────────────────
// Обертка над Telegram Web App API: тема, haptics, BackButton, MainButton.
// Всё безопасно работает и в обычном браузере (нет-операции).
// ─────────────────────────────────────────────────────────────────────────────

export type CloudStorageLike = {
  setItem(key: string, value: string, cb?: (err: string | null, ok?: boolean) => void): void;
  getItem(keys: string | string[], cb?: (err: string | null, value?: unknown) => void): void;
  getKeys(cb?: (err: string | null, keys?: string[]) => void): void;
  removeItem(keys: string | string[], cb?: (err: string | null, ok?: boolean) => void): void;
};

type ThemeParams = {
  bg_color?: string;
  secondary_bg_color?: string;
  text_color?: string;
  hint_color?: string;
  link_color?: string;
  button_color?: string;
  button_text_color?: string;
};

type BackButtonApi = {
  isVisible: boolean;
  show(): void;
  hide(): void;
  onClick(cb: () => void): void;
  offClick(cb: () => void): void;
};

type MainButtonApi = {
  setParams(p: Partial<{ text: string; color: string; text_color: string; is_active: boolean; is_visible: boolean }>): void;
  show(): void;
  hide(): void;
  enable(): void;
  disable(): void;
  onClick(cb: () => void): void;
  offClick(cb: () => void): void;
};

type HapticApi = {
  impactOccurred(style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft'): void;
  notificationOccurred(type: 'error' | 'success' | 'warning'): void;
  selectionChanged(): void;
};

type BiometricManagerApi = {
  isInited: boolean;
  isBiometricAvailable: boolean;
  biometricType: 'finger' | 'face' | 'unknown';
  isAccessRequested: boolean;
  isAccessGranted: boolean;
  deviceId: string;
  init(cb?: () => void): void;
  requestAccess(params: { reason?: string }, cb?: (granted: boolean) => void): void;
  authenticate(params: { reason?: string }, cb?: (ok: boolean, token?: string) => void): void;
  openSettings(): void;
};

export type TgWebApp = {
  initData: string;
  colorScheme?: 'light' | 'dark';
  themeParams: ThemeParams;
  version?: string;
  ready(): void;
  expand(): void;
  setHeaderColor(color: string): void;
  setBackgroundColor(color: string): void;
  onEvent(event: string, cb: () => void): void;
  offEvent?(event: string, cb: () => void): void;
  disableVerticalSwipes?(): void;
  BackButton: BackButtonApi;
  MainButton: MainButtonApi;
  HapticFeedback: HapticApi;
  CloudStorage?: CloudStorageLike;
  BiometricManager?: BiometricManagerApi;
};

declare global {
  interface Window {
    Telegram?: { WebApp?: TgWebApp };
  }
}

export const tg = () => window.Telegram?.WebApp;

/** Приложение реально запущено внутри Telegram (а не мок-страница в браузере) */
export const inTg = () => Boolean(tg()?.initData);

export const getCloudStorage = (): CloudStorageLike | null => {
  if (!inTg()) return null;
  const cs = tg()?.CloudStorage;
  return cs && typeof cs.setItem === 'function' && typeof cs.getItem === 'function' ? cs : null;
};
// ── Инициализация ────────────────────────────────────────────────────────────

export function initTelegram() {
  const t = tg();
  if (!t) return;
  try {
    t.ready();
    t.expand();
    t.disableVerticalSwipes?.();
  } catch {
    /* старая версия клиента — игнорируем */
  }
}

/** Применяет themeParams Telegram к CSS-переменным. Возвращает схему. */
export function applyTelegramTheme(): 'dark' | 'light' {
  const t = tg();
  const scheme: 'dark' | 'light' =
    t?.colorScheme === 'light' || t?.colorScheme === 'dark'
      ? t.colorScheme
      : window.matchMedia('(prefers-color-scheme: light)').matches
        ? 'light'
        : 'dark';

  const root = document.documentElement;
  root.dataset.theme = scheme;
  const tp = t?.themeParams ?? {};
  const set = (name: string, v?: string) => {
    if (v) root.style.setProperty(name, v);
    else root.style.removeProperty(name);
  };
  set('--tg-bg', tp.bg_color);
  set('--tg-card', tp.secondary_bg_color);
  set('--tg-text', tp.text_color);
  set('--tg-hint', tp.hint_color);

  const bg = tp.bg_color || (scheme === 'dark' ? '#0B0E14' : '#EEF2F7');
  if (inTg()) {
    try {
      t?.setHeaderColor(bg);
      t?.setBackgroundColor(bg);
    } catch {
      /* noop */
    }
  }
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', bg);
  return scheme;
}

// ── Haptics ──────────────────────────────────────────────────────────────────

const safe = (fn?: () => void) => {
  try {
    fn?.();
  } catch {
    /* noop */
  }
};

export const haptic = {
  tap: () => inTg() && safe(() => tg()?.HapticFeedback.impactOccurred('light')),
  select: () => inTg() && safe(() => tg()?.HapticFeedback.selectionChanged()),
  success: () => inTg() && safe(() => tg()?.HapticFeedback.notificationOccurred('success')),
  warn: () => inTg() && safe(() => tg()?.HapticFeedback.notificationOccurred('warning')),
  error: () => inTg() && safe(() => tg()?.HapticFeedback.notificationOccurred('error')),
};

// ── MainButton ───────────────────────────────────────────────────────────────

export const mb = {
  _handler: null as null | (() => void),
  show(text: string, onClick: () => void, active = true) {
    const t = tg();
    if (!inTg() || !t?.MainButton) return;
    safe(() => {
      if (this._handler) t.MainButton.offClick(this._handler);
      this._handler = onClick;
      t.MainButton.onClick(onClick);
      const tp = t.themeParams ?? {};
      const params: Parameters<typeof t.MainButton.setParams>[0] = { text, is_visible: true, is_active: active };
      if (tp.button_color) params.color = tp.button_color;
      if (tp.button_text_color) params.text_color = tp.button_text_color;
      t.MainButton.setParams(params);
    });
  },
  hide() {
    const t = tg();
    if (!inTg() || !t?.MainButton) return;
    safe(() => {
      if (this._handler) t.MainButton.offClick(this._handler);
      this._handler = null;
      t.MainButton.hide();
    });
  },
};

// ── BackButton ───────────────────────────────────────────────────────────────

export const bb = {
  _handler: null as null | (() => void),
  set(onClick: (() => void) | null) {
    const t = tg();
    if (!inTg() || !t?.BackButton) return;
    safe(() => {
      if (this._handler) t.BackButton.offClick(this._handler);
      this._handler = onClick;
      if (onClick) {
        t.BackButton.onClick(onClick);
        t.BackButton.show();
      } else {
        t.BackButton.hide();
      }
    });
  },
};
