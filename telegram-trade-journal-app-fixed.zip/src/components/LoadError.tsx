import { AlertTriangle, RefreshCw } from 'lucide-react';
import { store } from '../store';

/** Экран ошибки загрузки: пока данные не прочитаны, запись отключена, чтобы ничего не перезаписать */
export function LoadError() {
  return (
    <div className="splash">
      <div className="splash-logo num">40×20%</div>
      <div className="load-error" role="alert">
        <div className="load-error-title">
          <AlertTriangle size={17} strokeWidth={2.2} />
          Не удалось загрузить данные из облака Telegram
        </div>
        <p className="load-error-text">
          Записи в облаке не тронуты. Пока они не загружены, запись отключена — так ничего не перезапишется.
        </p>
        <button className="btn btn-accent wide" onClick={() => void store.load()}>
          <RefreshCw size={15} /> Повторить
        </button>
        <button className="btn btn-ghost wide" onClick={() => void store.useLocalOnly()}>
          Продолжить без облака
        </button>
        <p className="load-error-note">Без облака записи останутся только на этом устройстве и не попадут в облако Telegram.</p>
      </div>
    </div>
  );
}
