import { createPortal } from 'react-dom';
import { AlertTriangle, CheckCircle2, Info, PartyPopper, XCircle } from 'lucide-react';
import { store, useJournal } from '../store';
import type { ToastKind } from '../store';

const ICONS: Record<ToastKind, typeof Info> = {
  success: CheckCircle2,
  error: XCircle,
  warn: AlertTriangle,
  info: Info,
  goal: PartyPopper,
};

export function Toasts() {
  const st = useJournal();
  return createPortal(
    <div className="toasts">
      {st.toasts.map((t) => {
        const Icon = ICONS[t.kind];
        return (
          <div key={t.id} className={`toast t-${t.kind}`}>
            <Icon size={17} strokeWidth={2.2} />
            <span>{t.text}</span>
            {t.action && (
              <button
                className="toast-action"
                onClick={() => {
                  t.action?.run();
                  store.dismissToast(t.id);
                }}
              >
                {t.action.label}
              </button>
            )}
          </div>
        );
      })}
    </div>,
    document.body
  );
}
