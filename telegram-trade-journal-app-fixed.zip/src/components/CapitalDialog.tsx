import { useMemo, useState } from 'react';
import { store, useJournal } from '../store';
import {
  computeStats,
  compound,
  currentCapital,
  daysToReach,
  fmtMoney,
  fmtPct,
  parseNum,
  round2,
} from '../calc';
import { haptic, inTg } from '../telegram';
import { Sheet, useMainButton } from './dialogs';

const CURRENCIES = ['$', '€', '₽', 'USDT'];

export function CapitalDialog({ onClose }: { onClose: () => void }) {
  const st = useJournal();
  const [capStr, setCapStr] = useState(st.meta.startCapital ? String(st.meta.startCapital).replace('.', ',') : '');
  const [cur, setCur] = useState(st.meta.currency ?? '$');
  const [targetStr, setTargetStr] = useState('');

  const target = st.meta.dayTargetPct;
  const goal = st.meta.goalDays;
  const stats = useMemo(() => computeStats(st.days, st.meta), [st.days, st.meta]);
  const remaining = Math.max(0, goal - stats.closed);

  const start = parseNum(capStr);
  const valid = start !== null && start > 0 && start < 1e12;
  const base = valid ? start : null;

  const current = useMemo(() => (base !== null ? currentCapital(st.days, base) : null), [base, st.days]);
  const finalCap = current !== null ? compound(current, target, remaining) : null;
  const gainPct = base !== null && current !== null && base > 0 ? round2((current / base - 1) * 100) : 0;

  const maxSim = Math.max(1, remaining);
  const [simDays, setSimDays] = useState(() => Math.min(10, maxSim));
  const simCap = current !== null ? compound(current, target, Math.min(simDays, maxSim)) : null;

  // Вехи: 1 / 5 / 10 дней и «у цели»
  const milestones = useMemo(() => {
    if (current === null || remaining === 0) return [];
    const ks = [1, 5, 10].filter((k) => k < remaining);
    return [
      ...ks.map((k) => ({ label: `Через ${k} ${plural(k)}`, v: compound(current, target, k) })),
      { label: `У цели — ещё ${remaining} ${plural(remaining)}`, v: compound(current, target, remaining), last: true },
    ];
  }, [current, remaining, target]);

  // Логарифмическая шкала баров (экспонента иначе «взрывается»)
  const bars = useMemo(() => {
    if (current === null || remaining === 0) return [];
    const count = Math.min(remaining, 24);
    const maxV = compound(current, target, count);
    const arr = [{ k: 0, h: 8, v: current }];
    for (let k = 1; k <= count; k += 1) {
      const v = compound(current, target, k);
      arr.push({ k, v, h: Math.max(8, (Math.log(v) / Math.log(maxV)) * 100) });
    }
    return arr;
  }, [current, remaining, target]);

  const want = parseNum(targetStr);
  const needDays = want !== null && current !== null ? daysToReach(current, want, target) : null;

  const save = () => {
    if (!valid || start === null) {
      store.toast('error', 'Укажите положительную сумму капитала');
      haptic.error();
      return;
    }
    void store.setMeta({ startCapital: round2(start), currency: cur });
    haptic.success();
    store.toast('success', 'Стартовый капитал сохранён');
    onClose();
  };
  useMainButton('Сохранить капитал', save, valid);

  const clear = () => {
    void store.setMeta({ startCapital: undefined, currency: undefined });
    haptic.tap();
    store.toast('info', 'Начальный капитал убран');
    onClose();
  };

  return (
    <Sheet
      title="Калькулятор капитала"
      onClose={onClose}
      footer={
        <div className="foot-row">
          <button className="btn btn-ghost" onClick={onClose}>
            Закрыть
          </button>
          {!inTg() && (
            <button className="btn btn-accent" disabled={!valid} onClick={save}>
              Сохранить
            </button>
          )}
        </div>
      }
    >
      <div className="hint-box">
        Депозит пересчитывается автоматически после каждой засчитанной записи: капитал дня умножается на (1 + прогресс
        дня). Сложный процент, как на реальном счёте.
      </div>

      <label className="field">
        <span className="label">Начальный капитал</span>
        <div className="cap-input-row">
          <input
            className="input num"
            inputMode="decimal"
            placeholder="например, 1000"
            value={capStr}
            autoFocus
            onChange={(e) => setCapStr(e.target.value)}
          />
          <div className="cur-row">
            {CURRENCIES.map((c) => (
              <button
                key={c}
                type="button"
                className={`chip ${cur === c ? 'on' : ''}`}
                onClick={() => {
                  setCur(c);
                  haptic.select();
                }}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </label>

      {current !== null && (
        <>
          <div className="cap-stats">
            <div className="cap-stat">
              <span className="cap-stat-label">Сейчас ≈</span>
              <b className="num">{fmtMoney(current, cur)}</b>
              <span className={`cap-stat-sub ${gainPct >= 0 ? 'pos' : 'neg'}`}>
                {fmtPct(gainPct)} от старта
              </span>
            </div>
            <div className="cap-stat">
              <span className="cap-stat-label">После 40/40 ≈</span>
              <b className="num">{finalCap !== null ? fmtMoney(finalCap, cur) : '—'}</b>
              <span className="cap-stat-sub">
                {remaining > 0 ? `ещё ${remaining} ${plural(remaining)} × +${target}%` : 'цель выполнена'}
              </span>
            </div>
          </div>

          {bars.length > 1 && (
            <div className="cap-bars-wrap">
              <div className="cap-bars">
                {bars.map((b) => (
                  <div
                    key={b.k}
                    className={`cap-bar ${b.k === 0 ? 'now' : ''} ${b.k === Math.min(simDays, maxSim) ? 'on' : ''}`}
                    style={{ height: `${b.h}%` }}
                    title={fmtMoney(b.v, cur)}
                  />
                ))}
              </div>
              <div className="cap-bars-scale">
                <span>сейчас</span>
                <span>через {bars.length - 1} {plural(bars.length - 1)}</span>
              </div>
            </div>
          )}

          {remaining > 0 && simCap !== null && (
            <div className="cap-sim">
              <div className="cap-sim-head">
                <span>Симулятор</span>
                <b className="num">
                  ещё {Math.min(simDays, maxSim)} {plural(Math.min(simDays, maxSim))} → {fmtMoney(simCap, cur)}
                </b>
              </div>
              <input
                type="range"
                className="cap-range"
                min={1}
                max={maxSim}
                value={Math.min(simDays, maxSim)}
                style={{ '--fill': `${(Math.min(simDays, maxSim) / maxSim) * 100}%` } as React.CSSProperties}
                onChange={(e) => {
                  setSimDays(Number(e.target.value));
                  haptic.select();
                }}
              />
            </div>
          )}

          {milestones.length > 0 && (
            <div className="card-lite cap-ms">
              {milestones.map((m) => (
                <div key={m.label} className={`kv ${'last' in m && m.last ? 'accent-kv' : ''}`}>
                  <span>{m.label}</span>
                  <b className="num">{fmtMoney(m.v, cur)}</b>
                </div>
              ))}
            </div>
          )}

          {remaining === 0 && (
            <div className="hint-box">Цель выполнена — итоговый капитал ≈ {fmtMoney(current, cur)}. Дальше — новый марафон.</div>
          )}

          <div className="field">
            <span className="label">Обратный расчёт: хочу капитал</span>
            <div className="cap-rev-row">
              <input
                className="input num"
                inputMode="decimal"
                placeholder={base !== null ? fmtMoney(base * 5, cur) : '10000'}
                value={targetStr}
                onChange={(e) => setTargetStr(e.target.value)}
              />
              <div className="cap-rev-out num">
                {needDays === null ? '—' : needDays === 0 ? 'уже есть' : `≈${needDays} ${plural(needDays)}`}
              </div>
            </div>
          </div>
        </>
      )}

      {st.meta.startCapital !== undefined && (
        <button className="lock-bypass" onClick={clear}>
          Убрать начальный капитал
        </button>
      )}
    </Sheet>
  );
}

function plural(n: number): string {
  const a = Math.abs(n) % 10;
  const b = Math.abs(n) % 100;
  if (a === 1 && b !== 11) return 'день';
  if (a >= 2 && a <= 4 && (b < 12 || b > 14)) return 'дня';
  return 'дней';
}
