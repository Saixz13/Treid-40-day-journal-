import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { AlertTriangle, X } from 'lucide-react';
import type { Mark, Trade } from '../types';
import { store } from '../store';
import { haptic, inTg, mb } from '../telegram';
import { parseNum } from '../calc';
import { parseImport } from '../exporter';
import type { ParsedImport } from '../exporter';

// ── MainButton Telegram: показывается, пока открыт диалог ────────────────────

export function useMainButton(label: string, onClick: () => void, active: boolean) {
  const ref = useRef(onClick);
  ref.current = onClick;
  useEffect(() => {
    mb.show(label, () => ref.current(), active);
    return () => mb.hide();
  }, [label, active]);
}

// ── Bottom sheet ─────────────────────────────────────────────────────────────

export function Sheet({
  title,
  onClose,
  children,
  footer,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
}) {
  useEffect(() => {
    document.body.classList.add('locked');
    return () => document.body.classList.remove('locked');
  }, []);
  return createPortal(
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-handle" />
        <div className="sheet-head">
          <h3>{title}</h3>
          <button className="icon-btn" onClick={onClose} aria-label="Закрыть">
            <X size={18} />
          </button>
        </div>
        <div className="sheet-body">{children}</div>
        {footer ? <div className="sheet-foot">{footer}</div> : null}
      </div>
    </div>,
    document.body
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="field">
      <span className="label">{label}</span>
      {children}
    </label>
  );
}

// ── Диалог куска (добавление своего значения / редактирование) ───────────────

export function PctDialog({ date, mark, onClose }: { date: string; mark?: Mark; onClose: () => void }) {
  const [pctStr, setPctStr] = useState(mark ? String(mark.pct).replace('.', ',') : '');
  const [note, setNote] = useState(mark?.note ?? '');
  const [checked, setChecked] = useState(mark?.checked ?? true);
  const parsed = parseNum(pctStr);
  const valid = parsed !== null && parsed !== 0 && Math.abs(parsed) <= 100;

  const primary = () => {
    if (parsed === null || !valid) {
      store.toast('error', 'Нужно число от −100 до +100 (не ноль)');
      haptic.error();
      return;
    }
    const ok = mark
      ? store.updateMark(date, mark.id, { pct: parsed, note, checked })
      : store.addMark(date, parsed, note, checked);
    if (ok) onClose();
  };

  useMainButton(mark ? 'Сохранить' : 'Добавить кусок', primary, valid);

  return (
    <Sheet
      title={mark ? 'Редактировать кусок' : 'Свой кусок'}
      onClose={onClose}
      footer={
        <div className="foot-row">
          <button className="btn btn-ghost" onClick={onClose}>
            Отмена
          </button>
          {!inTg() && (
            <button className="btn btn-accent" disabled={!valid} onClick={primary}>
              {mark ? 'Сохранить' : 'Добавить'}
            </button>
          )}
        </div>
      }
    >
      <Field label="Значение, % к депозиту">
        <input
          className="input num"
          inputMode="decimal"
          placeholder="например, 12,5 или −5"
          value={pctStr}
          autoFocus
          onChange={(e) => setPctStr(e.target.value)}
        />
      </Field>
      <Field label="Заметка (необязательно)">
        <input
          className="input"
          placeholder="утренняя сессия, пробой диапазона…"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          maxLength={80}
        />
      </Field>
      <button
        type="button"
        className={`checkline ${checked ? 'on' : ''}`}
        onClick={() => {
          setChecked(!checked);
          haptic.select();
        }}
      >
        <span className={`row-check ${checked ? 'on' : ''}`}>{checked ? (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12" />
          </svg>
        ) : null}</span>
        <span>
          Учитывать в прогрессе дня
          <small>снятая галочка — запись остаётся, но в прогресс не идёт</small>
        </span>
      </button>
    </Sheet>
  );
}

// ── Диалог сделки (лог, не влияет на прогресс) ───────────────────────────────

export function TradeDialog({ date, onClose }: { date: string; onClose: () => void }) {
  const [symbol, setSymbol] = useState('');
  const [side, setSide] = useState<Trade['side']>(undefined);
  const [setup, setSetup] = useState('');
  const [riskStr, setRiskStr] = useState('');
  const [resultStr, setResultStr] = useState('');
  const [note, setNote] = useState('');

  const risk = parseNum(riskStr);
  const result = parseNum(resultStr);
  const riskOk = riskStr.trim() === '' || risk !== null;
  const resultOk = resultStr.trim() === '' || result !== null;
  const valid = riskOk && resultOk;

  const primary = () => {
    if (!valid) {
      store.toast('error', 'Риск и результат должны быть числами');
      haptic.error();
      return;
    }
    const ok = store.addTrade(date, {
      symbol: symbol.trim() || undefined,
      side,
      setup: setup.trim() || undefined,
      riskPct: risk ?? undefined,
      resultPct: result ?? undefined,
      note: note.trim() || undefined,
    });
    if (ok) onClose();
  };

  useMainButton('Сохранить сделку', primary, valid);

  return (
    <Sheet
      title="Сделка в лог"
      onClose={onClose}
      footer={
        <div className="foot-row">
          <button className="btn btn-ghost" onClick={onClose}>
            Отмена
          </button>
          {!inTg() && (
            <button className="btn btn-accent" disabled={!valid} onClick={primary}>
              Сохранить
            </button>
          )}
        </div>
      }
    >
      <div className="hint-box">Лог сделок — только история и заметки. На прогресс цели влияют лишь засчитанные куски.</div>
      <Field label="Инструмент">
        <input className="input" placeholder="BTCUSDT, ETH, SBER…" value={symbol} onChange={(e) => setSymbol(e.target.value)} maxLength={20} />
      </Field>
      <Field label="Направление">
        <div className="seg-toggle">
          {(['long', 'short'] as const).map((s) => (
            <button
              key={s}
              type="button"
              className={side === s ? `on ${s}` : ''}
              onClick={() => {
                setSide(side === s ? undefined : s);
                haptic.select();
              }}
            >
              {s === 'long' ? 'Long' : 'Short'}
            </button>
          ))}
        </div>
      </Field>
      <div className="grid-2">
        <Field label="Риск, %">
          <input className="input num" inputMode="decimal" placeholder="1" value={riskStr} onChange={(e) => setRiskStr(e.target.value)} />
        </Field>
        <Field label="Результат, %">
          <input className="input num" inputMode="decimal" placeholder="+2,5" value={resultStr} onChange={(e) => setResultStr(e.target.value)} />
        </Field>
      </div>
      <Field label="Сетап">
        <input className="input" placeholder="пробой, ретест, отскок…" value={setup} onChange={(e) => setSetup(e.target.value)} maxLength={60} />
      </Field>
      <Field label="Заметка">
        <textarea className="input textarea" placeholder="что увидел, как отработал…" value={note} onChange={(e) => setNote(e.target.value)} maxLength={240} />
      </Field>
    </Sheet>
  );
}

// ── Импорт JSON ──────────────────────────────────────────────────────────────

export function ImportDialog({ onClose }: { onClose: () => void }) {
  const [text, setText] = useState('');
  const [parsed, setParsed] = useState<ParsedImport | null>(null);

  const step = parsed ? 'confirm' : 'paste';

  const primary = () => {
    if (step === 'paste') {
      try {
        setParsed(parseImport(text));
        haptic.success();
      } catch (e) {
        store.toast('error', e instanceof Error ? e.message : 'Не удалось разобрать JSON');
        haptic.error();
      }
    } else if (parsed) {
      void store.replaceAll(parsed.days, parsed.meta);
      onClose();
    }
  };

  useMainButton(step === 'paste' ? 'Проверить данные' : 'Импортировать', primary, step === 'paste' ? text.trim().length > 2 : true);

  return (
    <Sheet
      title="Импорт JSON"
      onClose={onClose}
      footer={
        <div className="foot-row">
          {parsed && (
            <button className="btn btn-ghost" onClick={() => setParsed(null)}>
              Назад
            </button>
          )}
          <button className="btn btn-ghost" onClick={onClose}>
            Отмена
          </button>
          {!inTg() && (
            <button className="btn btn-accent" disabled={step === 'paste' && text.trim().length <= 2} onClick={primary}>
              {step === 'paste' ? 'Проверить' : 'Импортировать'}
            </button>
          )}
        </div>
      }
    >
      {step === 'paste' ? (
        <>
          <div className="hint-box">Вставьте JSON, полученный при экспорте. Текущие данные будут заменены после подтверждения.</div>
          <textarea
            className="input textarea code"
            placeholder='{"app":"trade-journal-40x20","meta":{...},"days":{...}}'
            value={text}
            onChange={(e) => setText(e.target.value)}
            spellCheck={false}
          />
        </>
      ) : (
        <>
          <div className="import-summary">
            <div className="kv">
              <span>Дней</span>
              <b className="num">{parsed?.counts.days}</b>
            </div>
            <div className="kv">
              <span>Кусков</span>
              <b className="num">{parsed?.counts.marks}</b>
            </div>
            <div className="kv">
              <span>Сделок в логе</span>
              <b className="num">{parsed?.counts.trades}</b>
            </div>
            {parsed?.meta && (
              <div className="kv">
                <span>Настройки цели из файла</span>
                <b className="num">
                  {parsed.meta.goalDays} × {parsed.meta.dayTargetPct}%
                </b>
              </div>
            )}
          </div>
          <div className="hint-box warn">
            <AlertTriangle size={16} />
            <span>Текущие данные будут полностью заменены содержимым файла.</span>
          </div>
        </>
      )}
    </Sheet>
  );
}

// ── Подтверждение ────────────────────────────────────────────────────────────

export function ConfirmDialog({
  title,
  body,
  confirmText,
  danger,
  onConfirm,
  onClose,
}: {
  title: string;
  body?: string;
  confirmText: string;
  danger?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}) {
  return (
    <Sheet
      title={title}
      onClose={onClose}
      footer={
        <div className="foot-row">
          <button className="btn btn-ghost" onClick={onClose}>
            Отмена
          </button>
          <button
            className={`btn ${danger ? 'btn-red' : 'btn-accent'}`}
            onClick={() => {
              haptic.tap();
              onConfirm(); // контракт: onConfirm сам решает, что дальше (закрыть или следующий шаг)
            }}
          >
            {confirmText}
          </button>
        </div>
      }
    >
      {body ? <p className="sheet-text">{body}</p> : null}
    </Sheet>
  );
}
