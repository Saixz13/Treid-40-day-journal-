import { useEffect, useState } from 'react';
import { Copy, Download } from 'lucide-react';
import { store } from '../store';
import { haptic } from '../telegram';
import { renderShareCard } from '../share';
import type { ShareImage } from '../share';
import { Sheet } from './dialogs';

export function ShareDialog({ onClose }: { onClose: () => void }) {
  const [img, setImg] = useState<ShareImage | null>(null);

  useEffect(() => {
    let alive = true;
    renderShareCard()
      .then((r) => {
        if (alive) setImg(r);
      })
      .catch(() => {
        store.toast('error', 'Не удалось сгенерировать карточку');
        if (alive) onClose();
      });
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const download = () => {
    if (!img) return;
    haptic.tap();
    const url = URL.createObjectURL(img.blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tj40-progress.png`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 4000);
    store.toast('success', 'PNG сохранён — проверьте загрузки');
  };

  const copy = async () => {
    if (!img) return;
    haptic.tap();
    try {
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': img.blob })]);
      store.toast('success', 'Картинка в буфере обмена');
    } catch {
      store.toast('warn', 'Копирование картинок тут не поддержано — скачайте PNG');
    }
  };

  return (
    <Sheet
      title="Карточка прогресса"
      onClose={onClose}
      footer={
        <div className="foot-row">
          <button className="btn btn-ghost" disabled={!img} onClick={copy}>
            <Copy size={15} /> Копировать
          </button>
          <button className="btn btn-accent" disabled={!img} onClick={download}>
            <Download size={15} /> PNG
          </button>
        </div>
      }
    >
      {img ? (
        <img className="share-preview" src={img.dataUrl} alt="Карточка прогресса" />
      ) : (
        <div className="share-loading">Рисуем карточку…</div>
      )}
      <div className="hint-box">
        Изображение генерируется локально на устройстве — данные никуда не отправляются. Подходит для сторис и чатов.
      </div>
    </Sheet>
  );
}
