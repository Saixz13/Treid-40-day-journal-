import { useState } from 'react';
import { Fingerprint } from 'lucide-react';
import { bioAuthenticate } from '../biometric';
import { haptic } from '../telegram';

export function LockScreen({ onUnlocked }: { onUnlocked: () => void }) {
  const [busy, setBusy] = useState(false);
  const [failed, setFailed] = useState(false);

  const attempt = async () => {
    if (busy) return;
    setBusy(true);
    const ok = await bioAuthenticate('Доступ к Trade Journal 40×20%');
    setBusy(false);
    if (ok) {
      haptic.success();
      onUnlocked();
    } else {
      haptic.error();
      setFailed(true);
    }
  };

  return (
    <div className="lock-screen">
      <div className="lock-logo num">40×20%</div>
      <div className="lock-sub">TRADE JOURNAL</div>
      <div className="lock-ic">
        <Fingerprint size={30} strokeWidth={1.8} />
      </div>
      <h2>Журнал заблокирован</h2>
      <p>Подтвердите личность биометрией Telegram, чтобы открыть данные</p>
      <button className="btn btn-accent" disabled={busy} onClick={attempt}>
        <Fingerprint size={16} /> {busy ? 'Проверяем…' : 'Разблокировать'}
      </button>
      {failed && (
        <button className="lock-bypass" onClick={onUnlocked}>
          Войти без биометрии
        </button>
      )}
    </div>
  );
}
