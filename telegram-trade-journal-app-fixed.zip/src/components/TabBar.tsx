import { Database, Gauge, History } from 'lucide-react';
import type { Tab } from '../types';
import { haptic } from '../telegram';

const ITEMS = [
  { id: 'day', label: 'День', Icon: Gauge },
  { id: 'history', label: 'История', Icon: History },
  { id: 'data', label: 'Данные', Icon: Database },
] as const;

export function TabBar({ tab, onChange }: { tab: Tab; onChange: (t: Tab) => void }) {
  return (
    <nav className="tabbar">
      {ITEMS.map(({ id, label, Icon }) => {
        const active = tab === id;
        return (
          <button
            key={id}
            className={`tab ${active ? 'active' : ''}`}
            onClick={() => {
              if (!active) {
                haptic.select();
                onChange(id);
              }
            }}
          >
            <Icon size={21} strokeWidth={active ? 2.5 : 2} />
            <span>{label}</span>
          </button>
        );
      })}
    </nav>
  );
}
