// ─────────────────────────────────────────────────────────────────────────────
// Хранение данных: Telegram CloudStorage → fallback на localStorage.
// Схема ключей:
//   meta          — { goalDays, dayTargetPct, createdAt, version }
//   idx:days      — JSON-массив дат, по которым есть данные
//   d:YYYY-MM-DD  — JSON документа дня { marks: [...], trades: [...] }
// Лимит CloudStorage: значение ≈ 4096 символов → держим запас VALUE_LIMIT.
//
// Внутри Telegram на localStorage сами НЕ откатываемся: если облако не ответило,
// detectBackend() бросает CloudUnavailableError, а стор показывает экран «Повторить».
// Так записи не расходятся между облаком и устройством.
// ─────────────────────────────────────────────────────────────────────────────
import { getCloudStorage } from './telegram';
import type { CloudStorageLike } from './telegram';

export type Backend = 'cloud' | 'local';

const LS_PREFIX = 'tj40:';
/** Безопасный лимит на одно значение (с запасом от 4096) */
export const VALUE_LIMIT = 3900;

/** Проверка доступности облака: 2 попытки по 5 с — мобильная сеть бывает медленной */
const PROBE_TIMEOUT_MS = 5000;
const PROBE_ATTEMPTS = 2;
const PROBE_RETRY_DELAY_MS = 500;
/** Таймаут обычных операций чтения/записи */
const OP_TIMEOUT_MS = 8000;

/** Облако Telegram есть, но не ответило: работать с ним нельзя, а молча уходить в localStorage опасно */
export class CloudUnavailableError extends Error {
  constructor() {
    super('Telegram CloudStorage не отвечает');
    this.name = 'CloudUnavailableError';
  }
}

let backendCache: Backend | null = null;
let probing: Promise<Backend> | null = null;

export const backend = (): Backend => backendCache ?? 'local';

type ProbeResult = 'ok' | 'unsupported' | 'failed';

const sleep = (ms: number) => new Promise<void>((res) => window.setTimeout(res, ms));

/** Одна проверка: getKeys с таймаутом. 'unsupported' — клиент Telegram старше 6.9, облака там нет */
function probeOnce(cs: CloudStorageLike): Promise<ProbeResult> {
  return new Promise<ProbeResult>((resolve) => {
    let settled = false;
    let timer = 0;
    const done = (r: ProbeResult) => {
      if (settled) return;
      settled = true;
      window.clearTimeout(timer);
      resolve(r);
    };
    timer = window.setTimeout(() => done('failed'), PROBE_TIMEOUT_MS);
    try {
      cs.getKeys((err) => done(err ? 'failed' : 'ok'));
    } catch (e) {
      // SDK Telegram бросает исключение синхронно, если версия клиента < 6.9
      done(/unsupported/i.test(String((e as Error)?.message ?? e)) ? 'unsupported' : 'failed');
    }
  });
}

async function probe(): Promise<Backend> {
  const cs = getCloudStorage();
  if (!cs) return 'local'; // обычный браузер / PWA вне Telegram
  for (let attempt = 0; attempt < PROBE_ATTEMPTS; attempt += 1) {
    if (attempt > 0) await sleep(PROBE_RETRY_DELAY_MS);
    const r = await probeOnce(cs);
    if (r === 'ok') return 'cloud';
    if (r === 'unsupported') return 'local';
  }
  throw new CloudUnavailableError();
}

/** Определяем backend один раз. Успех кэшируется, ошибка — нет: можно нажать «Повторить» */
export function detectBackend(): Promise<Backend> {
  if (backendCache) return Promise.resolve(backendCache);
  if (!probing) {
    probing = probe()
      .then((b) => {
        backendCache = b;
        return b;
      })
      .finally(() => {
        probing = null;
      });
  }
  return probing;
}

/** Осознанный выбор пользователя: работать только на устройстве (на время этой сессии) */
export function forceLocal(): void {
  backendCache = 'local';
}

/** CloudStorage, только если он реально подтверждён detectBackend() */
const activeCloud = () => (backendCache === 'cloud' ? getCloudStorage() : null);

function withTimeout<T>(p: Promise<T>, ms = OP_TIMEOUT_MS): Promise<T> {
  return Promise.race([p, new Promise<T>((_, rej) => window.setTimeout(() => rej(new Error('storage timeout')), ms))]);
}

export async function storageSet(key: string, value: string): Promise<void> {
  const cs = activeCloud();
  if (!cs) {
    localStorage.setItem(LS_PREFIX + key, value);
    return;
  }
  await withTimeout(
    new Promise<void>((res, rej) => {
      try {
        cs.setItem(key, value, (err) => (err ? rej(new Error(err)) : res()));
      } catch (e) {
        rej(e as Error);
      }
    })
  );
}

/** Пакетное чтение (CloudStorage умеет массив ключей за один вызов) */
export async function storageGetMany(keys: string[]): Promise<Record<string, string | null>> {
  const out: Record<string, string | null> = {};
  if (keys.length === 0) return out;
  const cs = activeCloud();
  if (!cs) {
    for (const k of keys) {
      const v = localStorage.getItem(LS_PREFIX + k);
      out[k] = v && v !== '' ? v : null;
    }
    return out;
  }
  const values = await withTimeout(
    new Promise<unknown>((res, rej) => {
      try {
        cs.getItem(keys, (err, value) => (err ? rej(new Error(err)) : res(value)));
      } catch (e) {
        rej(e as Error);
      }
    })
  );
  const map = (values ?? {}) as Record<string, string>;
  for (const k of keys) {
    const v = map[k];
    out[k] = typeof v === 'string' && v !== '' ? v : null;
  }
  return out;
}

export async function storageRemove(keys: string[]): Promise<void> {
  if (keys.length === 0) return;
  const cs = activeCloud();
  if (!cs) {
    for (const k of keys) localStorage.removeItem(LS_PREFIX + k);
    return;
  }
  await withTimeout(
    new Promise<void>((res, rej) => {
      try {
        cs.removeItem(keys, (err) => (err ? rej(new Error(err)) : res()));
      } catch (e) {
        rej(e as Error);
      }
    })
  );
}
