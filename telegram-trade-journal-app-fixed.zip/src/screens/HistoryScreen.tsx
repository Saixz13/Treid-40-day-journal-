import { useMemo, useState } from 'react';
import { ChevronRight, Flame, Inbox, Target, TrendingUp } from 'lucide-react';
import { useJournal } from '../store';
import { computeStats, dayProgress, fmtDayMonth, fmtPct, fmtWeekday, isDayClosed, relDay } from '../calc';
import { haptic } from '../telegram';

type Filter = 'all' | 'closed' | 'open';

const FILTERS: Array<{ id: Filter; label: string }> = [
  { id: 'all', label: 'Все' },
  { id: 'closed', label: 'Закрытые' },
  { id: 'open', label: 'Не закрытые' },
];

export function HistoryScreen({ onOpenDay }: { onOpenDay: (date: string) => void }) {
  const st = useJournal();
  const [filter, setFilter] = useState<Filter>('all');
  const target = st.meta.dayTargetPct;
  const goal = st.meta.goalDays;

  const stats = useMemo(() => computeStats(st.days, st.meta), [st.days, st.meta]);

  const rows = useMemo(
    () =>
      Object.keys(st.days)
        .sort()
        .reverse()
        .map((date) => ({
          date,
          p: dayProgress(st.days[date]),
          closed: isDayClosed(dayProgress(st.days[date]), target),
          hasMarks: st.days[date].marks.length > 0,
        })),
    [st.days, target]
  );

  const filtered = rows.filter((r) => (filter === 'all' ? true : filter === 'closed' ? r.closed : !r.closed));

  return (
    <section className="screen">
      {/* ── Статистика ── */}
      <div className="stats-grid">
        <div className="stat card">
          <div className="stat-ic ok">
            <Target size={17} />
          </div>
          <div className="stat-body">
            <span className="stat-label">Закрыто дней</span>
            <span className="stat-val num">
              {stats.closed}
              <i>/{goal}</i>
            </span>
          </div>
        </div>
        <div className="stat card">
          <div className="stat-ic hot">
            <Flame size={17} />
          </div>
          <div className="stat-body">
            <span className="stat-label">Текущая серия</span>
            <span className="stat-val num">
              {stats.streak}
              <i> дн.</i>
            </span>
          </div>
        </div>
        <div className="stat card">
          <div className="stat-ic best">
            <TrendingUp size={17} />
          </div>
          <div className="stat-body">
            <span className="stat-label">Лучший день</span>
            <span className="stat-val num">{stats.best ? fmtPct(stats.best.pct) : '—'}</span>
            {stats.best && <span className="stat-sub">{fmtDayMonth(stats.best.date)}</span>}
          </div>
        </div>
      </div>

      {/* ── Фильтры ── */}
      <div className="filter-row">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            className={`chip ${filter === f.id ? 'on' : ''}`}
            onClick={() => {
              setFilter(f.id);
              haptic.select();
            }}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* ── Список дней ── */}
      {filtered.length === 0 ? (
        <div className="empty-box big">
          <Inbox size={28} />
          <p>{rows.length === 0 ? 'Записей пока нет' : 'Под фильтр ничего не попало'}</p>
          <span>{rows.length === 0 ? 'Отметьте куски на вкладке «День» — история появится сама' : 'Попробуйте другой фильтр'}</span>
        </div>
      ) : (
        <div className="hist-list">
          {filtered.map((r) => (
            <button
              key={r.date}
              className="hist-row card"
              onClick={() => {
                haptic.select();
                onOpenDay(r.date);
              }}
            >
              <div className="hist-left">
                <span className="hist-date">
                  {relDay(r.date) ?? fmtWeekday(r.date)}, {fmtDayMonth(r.date)}
                </span>
                <span className="hist-year">{r.hasMarks ? `${relDay(r.date) ? `${fmtWeekday(r.date)}, ` : ''}${r.date}` : `только лог · ${r.date}`}</span>
              </div>
              <div className="hist-right">
                <span className={`hist-val num ${r.p > 0 ? 'pos' : r.p < 0 ? 'neg' : ''}`}>{fmtPct(r.p)}</span>
                <span className={`status-chip ${r.closed ? 'ok' : ''}`}>{r.closed ? 'Закрыт' : 'Не закрыт'}</span>
                <ChevronRight size={16} className="hist-chev" />
              </div>
            </button>
          ))}
        </div>
      )}
    </section>
  );
}
