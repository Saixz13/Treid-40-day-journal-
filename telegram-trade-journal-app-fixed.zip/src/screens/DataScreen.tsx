import { useMemo } from 'react';
import { Copy, Download, Fingerprint, HardDrive, Share2, ShieldAlert, Upload } from 'lucide-react';
import type { DialogState } from '../types';
import { store, useJournal } from '../store';
import { buildCSV, buildJSON, copyText, downloadFile, exportFileName } from '../exporter';
import { bioInit, bioRequestAccess, bioSupported } from '../biometric';
import { fmtTs } from '../calc';
import { haptic, inTg } from '../telegram';

export function DataScreen({ openDialog }: { openDialog: (d: DialogState | null) => void }) {
  const st = useJournal();

  const totals = useMemo(() => {
    let marks = 0;
    let trades = 0;
    let bytes = 0;
    for (const d of Object.keys(st.days)) {
      marks += st.days[d].marks.length;
      trades += st.days[d].trades.length;
      bytes += JSON.stringify(st.days[d]).length + 12;
    }
    return { marks, trades, bytes: Math.round(bytes / 10.24) / 100 }; // ≈ КБ
  }, [st.days]);

  const doCopy = async (kind: 'json' | 'csv') => {
    haptic.tap();
    const text = kind === 'json' ? buildJSON(st.meta, st.days) : buildCSV(st.days);
    const ok = await copyText(text);
    if (ok) store.toast('success', `${kind.toUpperCase()} скопирован в буфер обмена`);
    else store.toast('error', 'Буфер недоступен — скачайте файл');
  };

  const doDownload = (kind: 'json' | 'csv') => {
    haptic.tap();
    if (kind === 'json') downloadFile(exportFileName('json'), buildJSON(st.meta, st.days), 'application/json');
    else downloadFile(exportFileName('csv'), buildCSV(st.days), 'text/csv');
    store.toast('info', 'Файл сформирован — проверьте загрузки');
  };

  const toggleBio = async () => {
    haptic.select();
    if (!bioSupported()) {
      store.toast('warn', 'Биометрия Telegram доступна только внутри Mini App на этом устройстве');
      return;
    }
    if (st.meta.bioLock) {
      void store.setMeta({ bioLock: false });
      store.toast('info', 'Биометрическая защита отключена');
      return;
    }
    const available = await bioInit();
    if (!available) {
      store.toast('warn', 'На устройстве не настроена биометрия (Face ID / отпечаток)');
      return;
    }
    const granted = await bioRequestAccess('Разрешить вход в журнал по биометрии');
    if (!granted) {
      store.toast('warn', 'Доступ к биометрии не выдан');
      return;
    }
    void store.setMeta({ bioLock: true });
    store.toast('success', 'Защита включена — спросим при следующем входе');
  };

  const resetFlow = () => {
    haptic.warn();
    openDialog({
      kind: 'confirm',
      title: 'Сбросить все данные?',
      body: 'Будут удалены все дни, куски и лог сделок — из памяти и из облачного хранилища. Отменить это действие нельзя.',
      confirmText: 'Продолжить',
      danger: true,
      onConfirm: () =>
        openDialog({
          kind: 'confirm',
          title: 'Точно удалить всё?',
          body: 'Второе подтверждение: данные стираются безвозвратно. Прогресс цели обнулится.',
          confirmText: 'Да, удалить всё',
          danger: true,
          onConfirm: () => {
            void store.resetAll();
            openDialog(null);
          },
        }),
    });
  };

  return (
    <section className="screen">
      {/* ── Хранилище ── */}
      <div className="data-card card">
        <div className="dc-head">
          <div className="dc-ic">
            <HardDrive size={17} />
          </div>
          <div>
            <div className="dc-title">Хранилище</div>
            <div className="dc-desc">
              {st.backend === 'cloud'
                ? 'Telegram CloudStorage — данные привязаны к вашему аккаунту'
                : inTg()
                  ? 'Без облака — данные только на этом устройстве и не попадут в облако Telegram'
                  : 'localStorage — локальный режим (вне Telegram)'}
            </div>
          </div>
        </div>
        <div className="kv-list">
          <div className="kv">
            <span>Дней с записями</span>
            <b className="num">{Object.keys(st.days).length}</b>
          </div>
          <div className="kv">
            <span>Кусков</span>
            <b className="num">{totals.marks}</b>
          </div>
          <div className="kv">
            <span>Сделок в логе</span>
            <b className="num">{totals.trades}</b>
          </div>
          <div className="kv">
            <span>Объём данных</span>
            <b className="num">≈{totals.bytes} КБ</b>
          </div>
          <div className="kv">
            <span>Журнал создан</span>
            <b className="num">{fmtTs(st.meta.createdAt)}</b>
          </div>
        </div>
        <div className="hint-box">Каждый день — отдельный ключ (d:ГГГГ-ММ-ДД, лимит ≈4 КБ). При переполнении дня приложение предупредит.</div>
      </div>

      {/* ── Экспорт ── */}
      <div className="data-card card">
        <div className="dc-head">
          <div className="dc-ic">
            <Download size={17} />
          </div>
          <div>
            <div className="dc-title">Экспорт</div>
            <div className="dc-desc">Резервная копия всех данных. JSON — полный снимок, CSV — для таблиц.</div>
          </div>
        </div>
        <div className="btn-row">
          <button className="btn btn-ghost" onClick={() => doCopy('json')}>
            <Copy size={15} /> JSON
          </button>
          <button className="btn btn-ghost" onClick={() => doDownload('json')}>
            <Download size={15} /> JSON
          </button>
        </div>
        <div className="btn-row">
          <button className="btn btn-ghost" onClick={() => doCopy('csv')}>
            <Copy size={15} /> CSV
          </button>
          <button className="btn btn-ghost" onClick={() => doDownload('csv')}>
            <Download size={15} /> CSV
          </button>
        </div>
      </div>

      {/* ── Импорт ── */}
      <div className="data-card card">
        <div className="dc-head">
          <div className="dc-ic">
            <Upload size={17} />
          </div>
          <div>
            <div className="dc-title">Импорт JSON</div>
            <div className="dc-desc">Восстановление из резервной копии. Вставите JSON и подтвердите замену.</div>
          </div>
        </div>
        <button
          className="btn btn-ghost wide"
          onClick={() => {
            haptic.tap();
            openDialog({ kind: 'import' });
          }}
        >
          <Upload size={15} /> Открыть импорт
        </button>
      </div>

      {/* ── Карточка прогресса ── */}
      <div className="data-card card">
        <div className="dc-head">
          <div className="dc-ic">
            <Share2 size={17} />
          </div>
          <div>
            <div className="dc-title">Карточка прогресса</div>
            <div className="dc-desc">Красивый PNG со статистикой цели для сторис и чатов — рисуется локально на устройстве.</div>
          </div>
        </div>
        <button
          className="btn btn-accent wide"
          onClick={() => {
            haptic.tap();
            openDialog({ kind: 'share' });
          }}
        >
          <Share2 size={15} /> Сгенерировать карточку
        </button>
      </div>

      {/* ── Приватность ── */}
      <div className="data-card card">
        <div className="dc-head center">
          <div className="dc-ic">
            <Fingerprint size={17} />
          </div>
          <div>
            <div className="dc-title">Биометрическая защита</div>
            <div className="dc-desc">Face ID / отпечаток Telegram при открытии</div>
          </div>
          <button
            className={`switch ${st.meta.bioLock ? 'on' : ''}`}
            onClick={() => void toggleBio()}
            role="switch"
            aria-checked={Boolean(st.meta.bioLock)}
            aria-label="Биометрическая защита"
          />
        </div>
      </div>

      {/* ── Опасная зона ── */}
      <div className="data-card card danger">
        <div className="dc-head">
          <div className="dc-ic red">
            <ShieldAlert size={17} />
          </div>
          <div>
            <div className="dc-title">Сброс данных</div>
            <div className="dc-desc">Полное удаление журнала. Потребуется двойное подтверждение.</div>
          </div>
        </div>
        <button className="btn btn-red-ghost wide" onClick={resetFlow}>
          <ShieldAlert size={15} /> Сбросить всё
        </button>
      </div>
    </section>
  );
}
