import { useMemo, useState } from 'react';
import type { CSSProperties } from 'react';
import {
  BadgeCheck,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Pencil,
  Plus,
  SlidersHorizontal,
  Trash2,
  Wallet,
} from 'lucide-react';
import type { DialogState, Mark, Trade } from '../types';
import { store, useJournal } from '../store';
import {
  addDays,
  clamp,
  computeStats,
  currentCapital,
  dayProgress,
  dayUncheckedSum,
  fmtDayMonth,
  fmtFullDate,
  fmtMoney,
  fmtPct,
  fmtPlain,
  fmtWeekday,
  isDayClosed,
  relDay,
  round2,
  todayISO,
} from '../calc';
import { GoalRing } from '../components/GoalRing';
import { haptic } from '../telegram';
import { useSpringNumber } from '../hooks';

export function DayScreen({
  date,
  onDate,
  openDialog,
}: {
  date: string;
  onDate: (d: string) => void;
  openDialog: (d: DialogState) => void;
}) {
  const st = useJournal();
  const doc = st.days[date];
  const marks = doc?.marks ?? [];
  const trades = doc?.trades ?? [];

  const progress = dayProgress(doc);
  const uncheckedSum = dayUncheckedSum(doc);
  const target = st.meta.dayTargetPct;
  const goal = st.meta.goalDays;
  const closed = isDayClosed(progress, target);
  const stats = useMemo(() => computeStats(st.days, st.meta), [st.days, st.meta]);

  const today = todayISO();
  const celebrating = st.celebrate === date;
  const remaining = round2(target - progress);
  const over = round2(progress - target);
  const [tradesOpen, setTradesOpen] = useState(false);
  const shownProgress = useSpringNumber(progress);

  // Капитал: стартовый из meta, прошитый через засчитанный прогресс всех дней
  const capSet = typeof st.meta.startCapital === 'number' && st.meta.startCapital > 0;
  const currentCap = useMemo(
    () => (capSet ? currentCapital(st.days, st.meta.startCapital as number) : null),
    [capSet, st.days, st.meta.startCapital]
  );

  const shift = (delta: number) => {
    onDate(addDays(date, delta));
    haptic.tap();
  };

  return (
    <section className="screen">
      {/* ── Переключатель даты ── */}
      <div className="date-nav">
        <button className="icon-btn" onClick={() => shift(-1)} aria-label="День назад">
          <ChevronLeft size={20} />
        </button>
        <div className="date-center">
          <input
            type="date"
            className="date-overlay-input"
            value={date}
            onChange={(e) => {
              if (e.target.value) {
                onDate(e.target.value);
                haptic.select();
              }
            }}
            aria-label="Выбрать дату"
          />
          <div className="date-center-inner">
            <span className="date-primary">{relDay(date) ?? fmtDayMonth(date)}</span>
            <span className="date-secondary">
              {relDay(date) ? `${fmtWeekday(date)}, ${fmtDayMonth(date)}` : fmtFullDate(date)}
            </span>
          </div>
        </div>
        <button className="icon-btn" onClick={() => shift(1)} aria-label="День вперёд">
          <ChevronRight size={20} />
        </button>
      </div>
      {date !== today && (
        <button
          className="today-chip"
          onClick={() => {
            onDate(today);
            haptic.select();
          }}
        >
          Вернуться к сегодня
        </button>
      )}

      {/* ── Герой: прогресс дня ── */}
      <div className={`hero card ${closed ? 'closed' : ''}`}>
        <div className="hero-top">
          <span className="hero-label">Прогресс дня</span>
          {closed ? (
            <span className="hero-badge ok">
              <BadgeCheck size={14} /> День закрыт
            </span>
          ) : progress < 0 ? (
            <span className="hero-badge neg">В минусе</span>
          ) : (
            <span className="hero-badge">Осталось {fmtPct(remaining, false)}</span>
          )}
        </div>

        <div className="ring-wrap">
          <GoalRing fraction={clamp(progress / target, 0, 1)} closed={closed} negative={progress < 0} />
          <div className="ring-center">
            <div className={`big-num num ${progress < 0 ? 'neg' : ''}`}>{fmtPct(shownProgress)}</div>
            <div className="big-sub">из +{fmtPlain(target)}%</div>
          </div>
          {celebrating && <Burst />}
        </div>

        <div className="hero-status">
          {closed ? (
            <>
              Засчитано <b className="accent-text">{fmtPct(progress)}</b> — день в зачёте цели
            </>
          ) : progress >= 0 ? (
            <>
              Засчитано <b>{fmtPct(progress)}</b> из +{fmtPlain(target)}%
              {uncheckedSum !== 0 && <span className="dim"> · не в зачёте {fmtPct(uncheckedSum)}</span>}
            </>
          ) : (
            <>
              День в минусе — до цели <b>{fmtPct(remaining, false)}</b>
            </>
          )}
        </div>
        {closed && over > 0 && <div className="over-note">Излишек {fmtPct(over)} не переносится — 1 день = 1 закрытие</div>}

        <div className="goal-strip">
          <div className="gs-head">
            <span>
              Цель — {goal} дней × +{fmtPlain(target)}%
            </span>
            <b className="num">
              {stats.closed}
              <i>/{goal}</i>
            </b>
          </div>
          <div className="segments" style={{ gridTemplateColumns: `repeat(${Math.ceil(goal / 2)}, 1fr)` }}>
            {Array.from({ length: goal }, (_, i) => (
              <span
                key={i}
                className={`seg ${i < Math.min(stats.closed, goal) ? 'filled' : ''}`}
                style={{ animationDelay: `${i * 14}ms` }}
              />
            ))}
          </div>
        </div>

        <button className="capital-strip" onClick={() => openDialog({ kind: 'capital' })}>
          <span className="cap-ic">
            <Wallet size={15} />
          </span>
          <span className="cap-main">
            <span className="cap-label">Капитал ≈</span>
            <b className="num">{capSet && currentCap !== null ? fmtMoney(currentCap, st.meta.currency ?? '$') : 'не задан'}</b>
          </span>
          <span className="cap-cta">Калькулятор</span>
        </button>
      </div>

      {/* ── Быстрое добавление ── */}
      <div className="sec-head">
        <h2 className="sec-title">Добавить кусок</h2>
      </div>
      <div className="quick-grid">
        {[5, 10, 20].map((v) => (
          <button key={v} className="quick-btn" onClick={() => store.addMark(date, v)}>
            <span className="num">+{v}%</span>
          </button>
        ))}
        <button className="quick-btn custom" onClick={() => openDialog({ kind: 'mark-add', date })}>
          <SlidersHorizontal size={16} />
          <span>Своё</span>
        </button>
      </div>

      {/* ── Куски за день ── */}
      <div className="sec-head">
        <h2 className="sec-title">Куски за день</h2>
        {marks.length > 0 && <span className="sec-count num">{marks.length}</span>}
      </div>
      {marks.length === 0 ? (
        <div className="empty-box">Пока пусто. День закрывается засчитанными кусками — например, +10% и ещё +10%.</div>
      ) : (
        <div className="list-card">
          {marks.map((m) => (
            <MarkRow key={m.id} m={m} date={date} openDialog={openDialog} />
          ))}
          <div className="list-foot">
            Зачтено <b>{fmtPct(progress)}</b> из +{fmtPlain(target)}%
            {uncheckedSum !== 0 && <span className="dim"> · не в зачёте {fmtPct(uncheckedSum)}</span>}
          </div>
        </div>
      )}

      {/* ── Лог сделок ── */}
      <button
        className="sec-head clickable"
        onClick={() => {
          setTradesOpen(!tradesOpen);
          haptic.select();
        }}
      >
        <h2 className="sec-title">
          Лог сделок
          <span className="sec-tag">не влияет на прогресс</span>
        </h2>
        <span className={`chev ${tradesOpen ? 'open' : ''}`}>
          <ChevronDown size={18} />
        </span>
      </button>
      {tradesOpen && (
        <>
          <button className="btn btn-ghost wide" onClick={() => openDialog({ kind: 'trade-add', date })}>
            <Plus size={16} /> Добавить сделку в лог
          </button>
          {trades.length > 0 && (
            <div className="list-card">
              {trades.map((t) => (
                <TradeRow key={t.id} t={t} date={date} />
              ))}
            </div>
          )}
        </>
      )}
    </section>
  );
}

// ── Строка куска ─────────────────────────────────────────────────────────────

function MarkRow({ m, date, openDialog }: { m: Mark; date: string; openDialog: (d: DialogState) => void }) {
  return (
    <div className={`row ${m.checked ? '' : 'off'}`}>
      <button
        className={`row-check ${m.checked ? 'on' : ''}`}
        onClick={() => store.toggleMark(date, m.id)}
        aria-label={m.checked ? 'Убрать из прогресса' : 'Учитывать в прогрессе'}
      >
        {m.checked && <Check size={14} strokeWidth={3.2} />}
      </button>
      <div className="row-main">
        <div className="trade-top">
          <span className={`row-val num ${m.pct < 0 ? 'neg' : ''}`}>{fmtPct(m.pct)}</span>
          {!m.checked && <span className="row-tag">не в зачёте</span>}
        </div>
        {m.note && <span className="row-note">{m.note}</span>}
      </div>
      <div className="row-actions">
        <button className="icon-btn sm" onClick={() => openDialog({ kind: 'mark-edit', date, mark: m })} aria-label="Редактировать">
          <Pencil size={15} />
        </button>
        <button className="icon-btn sm danger" onClick={() => store.deleteMark(date, m.id)} aria-label="Удалить">
          <Trash2 size={15} />
        </button>
      </div>
    </div>
  );
}

// ── Строка сделки ────────────────────────────────────────────────────────────

function TradeRow({ t, date }: { t: Trade; date: string }) {
  const sub = [t.setup, typeof t.riskPct === 'number' ? `риск ${fmtPct(t.riskPct, false)}` : null, t.note]
    .filter(Boolean)
    .join(' · ');
  return (
    <div className="row">
      <div className="row-main">
        <div className="trade-top">
          {t.symbol && <span className="trade-symbol">{t.symbol}</span>}
          {t.side && <span className={`badge-side ${t.side}`}>{t.side === 'long' ? 'LONG' : 'SHORT'}</span>}
          {typeof t.resultPct === 'number' && (
            <span className={`trade-result num ${t.resultPct >= 0 ? 'pos' : 'neg'}`}>{fmtPct(t.resultPct)}</span>
          )}
          {!t.symbol && !t.side && typeof t.resultPct !== 'number' && <span className="row-note">запись</span>}
        </div>
        {sub && <span className="row-note">{sub}</span>}
      </div>
      <div className="row-actions">
        <button className="icon-btn sm danger" onClick={() => store.deleteTrade(date, t.id)} aria-label="Удалить сделку">
          <Trash2 size={15} />
        </button>
      </div>
    </div>
  );
}

// ── Всплеск частиц при закрытии дня ──────────────────────────────────────────

function Burst() {
  const parts = useMemo(
    () =>
      Array.from({ length: 18 }, (_, i) => ({
        ang: (i / 18) * 360 + Math.random() * 16,
        dist: 78 + Math.random() * 46,
        delay: Math.random() * 0.12,
        size: 4 + Math.random() * 5,
        color: i % 3,
      })),
    []
  );
  return (
    <div className="burst" aria-hidden>
      {parts.map((p, i) => (
        <i
          key={i}
          className={`c${p.color}`}
          style={
            {
              '--ang': `${p.ang}deg`,
              '--dist': `${p.dist}px`,
              width: p.size,
              height: p.size,
              animationDelay: `${p.delay}s`,
            } as CSSProperties
          }
        />
      ))}
    </div>
  );
}
