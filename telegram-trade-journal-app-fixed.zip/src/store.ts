// ─────────────────────────────────────────────────────────────────────────────
// Единый стор журнала: состояние в памяти + персистентность в CloudStorage.
// UI подписан через useSyncExternalStore.
// ─────────────────────────────────────────────────────────────────────────────
import { useSyncExternalStore } from 'react';
import type { DayDoc, Mark, Meta, Trade } from './types';
import { defaultMeta } from './types';
import * as S from './storage';
import {
  DATE_RE,
  K_IDX,
  K_META,
  clamp,
  computeStats,
  currentCapital,
  dayKey,
  dayProgress,
  fmtMoney,
  isDayClosed,
  round2,
  uid,
} from './calc';
import { haptic, inTg } from './telegram';

export type Backend = S.Backend;
export type ToastKind = 'success' | 'error' | 'info' | 'warn' | 'goal';
export type ToastAction = { label: string; run: () => void };
export type Toast = { id: string; kind: ToastKind; text: string; action?: ToastAction };

export type JournalState = {
  ready: boolean;
  /** загрузка не удалась: запись заблокирована, пока пользователь не нажмёт «Повторить» */
  loadError: boolean;
  backend: Backend;
  meta: Meta;
  days: Record<string, DayDoc>;
  /** дата, по которой только что прошло празднование закрытия */
  celebrate: string | null;
  toasts: Toast[];
};

const emptyDay = (): DayDoc => ({ marks: [], trades: [] });

class Store {
  private state: JournalState = {
    ready: false,
    loadError: false,
    backend: 'local',
    meta: defaultMeta(),
    days: {},
    celebrate: null,
    toasts: [],
  };

  private listeners = new Set<() => void>();
  private celebrateTimer: number | null = null;
  private lastIdxJson = '';

  subscribe = (fn: () => void) => {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  };

  get = () => this.state;

  private set(patch: Partial<JournalState>) {
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((l) => l());
  }

  // ── Toasts ─────────────────────────────────────────────────────────────

  toast(kind: ToastKind, text: string, action?: ToastAction, ttl?: number) {
    const t: Toast = { id: uid(), kind, text, action };
    this.set({ toasts: [...this.state.toasts.slice(-2), t] });
    window.setTimeout(
      () => this.dismissToast(t.id),
      ttl ?? (action ? 5200 : 3200) // тосты с «Отменить» живут дольше
    );
  }

  dismissToast(id: string) {
    if (!this.state.toasts.some((x) => x.id === id)) return;
    this.set({ toasts: this.state.toasts.filter((x) => x.id !== id) });
  }

  // ── Загрузка ───────────────────────────────────────────────────────────

  private loading: Promise<void> | null = null;

  /** Идемпотентно: повторный вызов во время загрузки возвращает тот же промис */
  load(): Promise<void> {
    if (!this.loading) {
      this.loading = this.doLoad().finally(() => {
        this.loading = null;
      });
    }
    return this.loading;
  }

  private async doLoad() {
    this.set({ ready: false, loadError: false });
    try {
      const be = await S.detectBackend();
      const boot = await S.storageGetMany([K_META, K_IDX]);

      let meta = defaultMeta();
      if (boot[K_META]) {
        try {
          meta = { ...meta, ...JSON.parse(boot[K_META] as string) };
        } catch {
          /* битая мета — используем дефолт */
        }
      } else {
        try {
          await S.storageSet(K_META, JSON.stringify(meta));
        } catch {
          /* первая запись меты не критична — повторится при сохранении настроек */
        }
      }

      let dates: string[] = [];
      if (boot[K_IDX]) {
        try {
          const parsed = JSON.parse(boot[K_IDX] as string);
          if (Array.isArray(parsed)) dates = parsed.filter((d): d is string => typeof d === 'string' && DATE_RE.test(d));
        } catch {
          /* битый индекс — стартуем с пустого */
        }
      }

      const docs = await S.storageGetMany(dates.map(dayKey));
      const days: Record<string, DayDoc> = {};
      for (const d of dates) {
        const raw = docs[dayKey(d)];
        if (!raw) continue;
        try {
          const p = JSON.parse(raw);
          days[d] = {
            marks: Array.isArray(p?.marks) ? p.marks : [],
            trades: Array.isArray(p?.trades) ? p.trades : [],
          };
        } catch {
          /* битый день пропускаем */
        }
      }
      this.set({ ready: true, loadError: false, backend: be, meta, days });
      if (be === 'local' && inTg()) {
        this.toast('warn', 'Облако Telegram недоступно — записи хранятся только на этом устройстве', undefined, 7000);
      }
    } catch (e) {
      console.error(e);
      // Данные НЕ прочитаны: писать нельзя. Иначе пустое состояние перезапишет индекс дат
      // в облаке, и все прежние дни пропадут из журнала. Показываем экран «Повторить».
      this.set({ ready: false, loadError: true });
    }
  }

  /** Осознанный выбор пользователя: работать без облака (только эту сессию) */
  async useLocalOnly() {
    S.forceLocal();
    await this.load();
  }

  // ── Мета / настройки ───────────────────────────────────────────────────

  async setMeta(patch: Partial<Meta>) {
    const meta = { ...this.state.meta, ...patch };
    this.set({ meta });
    try {
      await S.storageSet(K_META, JSON.stringify(meta));
    } catch {
      this.toast('error', 'Не удалось сохранить настройки');
    }
  }

  // ── Запись ─────────────────────────────────────────────────────────────

  private day(date: string): DayDoc {
    return this.state.days[date] ?? emptyDay();
  }

  /** Защита от переполнения значения CloudStorage (~4096 символов) */
  private guardSize(doc: DayDoc): boolean {
    if (JSON.stringify(doc).length > S.VALUE_LIMIT) {
      haptic.warn();
      this.toast('warn', 'Лимит хранилища для этого дня исчерпан (≈4 КБ). Удалите часть записей.');
      return false;
    }
    return true;
  }

  private commitDay(date: string, doc: DayDoc) {
    const days: Record<string, DayDoc> = { ...this.state.days };
    if (doc.marks.length === 0 && doc.trades.length === 0) delete days[date];
    else days[date] = doc;
    this.set({ days });
    void this.persistDay(date, days[date]);
    void this.persistIdx(days);
  }

  private async persistDay(date: string, doc?: DayDoc) {
    try {
      if (doc) await S.storageSet(dayKey(date), JSON.stringify(doc));
      else await S.storageRemove([dayKey(date)]);
    } catch {
      this.toast('error', 'Ошибка записи в хранилище');
    }
  }

  private async persistIdx(days: Record<string, DayDoc>) {
    const json = JSON.stringify(Object.keys(days).sort());
    if (json === this.lastIdxJson) return;
    this.lastIdxJson = json;
    if (json.length > S.VALUE_LIMIT) {
      this.toast('warn', 'Слишком много дней: индекс хранилища почти заполнен');
      return;
    }
    try {
      await S.storageSet(K_IDX, json);
    } catch {
      this.toast('error', 'Ошибка записи индекса дат');
    }
  }

  // ── Реакция на изменение прогресса дня ────────────────────────────────

  private afterProgressChange(date: string, before: number, after: number) {
    const target = this.state.meta.dayTargetPct;
    const was = isDayClosed(before, target);
    const now = isDayClosed(after, target);

    if (!was && now) {
      haptic.success();
      const stats = computeStats(this.state.days, this.state.meta);
      const goal = this.state.meta.goalDays;
      const startCap = this.state.meta.startCapital;
      const capSuffix =
        startCap && startCap > 0
          ? ` · ≈${fmtMoney(currentCapital(this.state.days, startCap), this.state.meta.currency ?? '$')}`
          : '';
      if (stats.closed >= goal) this.toast('goal', `Цель выполнена — ${stats.closed}/${goal}! Поздравляем!${capSuffix}`);
      else this.toast('success', `День закрыт! Цель: ${stats.closed}/${goal}${capSuffix}`);
      this.fireCelebrate(date);
    } else if (was && !now) {
      haptic.warn();
      this.toast('warn', 'День снова открыт');
    }
  }

  private fireCelebrate(date: string) {
    if (this.celebrateTimer) window.clearTimeout(this.celebrateTimer);
    this.set({ celebrate: date });
    this.celebrateTimer = window.setTimeout(() => this.set({ celebrate: null }), 1700);
  }

  // ── Куски (Mark) ────────────────────────────────────────────────────────

  addMark(date: string, pct: number, note = '', checked = true): boolean {
    const d = this.day(date);
    const before = dayProgress(d);
    const mark: Mark = {
      id: uid(),
      date,
      pct: round2(pct),
      note: note.trim() || undefined,
      checked,
      createdAt: Date.now(),
    };
    const doc: DayDoc = { marks: [...d.marks, mark], trades: d.trades };
    if (!this.guardSize(doc)) return false;
    this.commitDay(date, doc);
    haptic.tap();
    this.afterProgressChange(date, before, dayProgress(doc));
    return true;
  }

  toggleMark(date: string, id: string) {
    const d = this.day(date);
    const before = dayProgress(d);
    const doc: DayDoc = {
      marks: d.marks.map((m) => (m.id === id ? { ...m, checked: !m.checked } : m)),
      trades: d.trades,
    };
    this.commitDay(date, doc);
    haptic.select();
    this.afterProgressChange(date, before, dayProgress(doc));
  }

  updateMark(date: string, id: string, patch: { pct: number; note?: string; checked: boolean }): boolean {
    const d = this.day(date);
    const before = dayProgress(d);
    const doc: DayDoc = {
      marks: d.marks.map((m) =>
        m.id === id ? { ...m, pct: round2(patch.pct), note: patch.note?.trim() || undefined, checked: patch.checked } : m
      ),
      trades: d.trades,
    };
    if (!this.guardSize(doc)) return false;
    this.commitDay(date, doc);
    haptic.tap();
    this.afterProgressChange(date, before, dayProgress(doc));
    return true;
  }

  deleteMark(date: string, id: string) {
    const d = this.day(date);
    const idx = d.marks.findIndex((m) => m.id === id);
    if (idx < 0) return;
    const removed = d.marks[idx];
    const before = dayProgress(d);
    const doc: DayDoc = { marks: d.marks.filter((m) => m.id !== id), trades: d.trades };
    this.commitDay(date, doc);
    haptic.tap();
    this.toast('info', 'Кусок удалён', { label: 'Отменить', run: () => this.restoreMark(date, removed, idx) });
    this.afterProgressChange(date, before, dayProgress(doc));
  }

  /** Undo: вернуть удалённый кусок на прежнюю позицию */
  restoreMark(date: string, mark: Mark, index: number) {
    const d = this.day(date);
    if (d.marks.some((m) => m.id === mark.id)) return;
    const before = dayProgress(d);
    const marks = [...d.marks];
    marks.splice(clamp(index, 0, marks.length), 0, mark);
    const doc: DayDoc = { marks, trades: d.trades };
    if (!this.guardSize(doc)) return;
    this.commitDay(date, doc);
    haptic.select();
    this.toast('success', 'Кусок восстановлен');
    this.afterProgressChange(date, before, dayProgress(doc));
  }

  // ── Сделки (Trade) ─────────────────────────────────────────────────────

  addTrade(date: string, data: Omit<Trade, 'id' | 'date' | 'createdAt'>): boolean {
    const d = this.day(date);
    const trade: Trade = { id: uid(), date, ...data, createdAt: Date.now() };
    const doc: DayDoc = { marks: d.marks, trades: [...d.trades, trade] };
    if (!this.guardSize(doc)) return false;
    this.commitDay(date, doc);
    haptic.tap();
    this.toast('success', 'Сделка добавлена в лог');
    return true;
  }

  deleteTrade(date: string, id: string) {
    const d = this.day(date);
    const idx = d.trades.findIndex((t) => t.id === id);
    if (idx < 0) return;
    const removed = d.trades[idx];
    const doc: DayDoc = { marks: d.marks, trades: d.trades.filter((t) => t.id !== id) };
    this.commitDay(date, doc);
    haptic.tap();
    this.toast('info', 'Сделка удалена', { label: 'Отменить', run: () => this.restoreTrade(date, removed, idx) });
  }

  /** Undo: вернуть удалённую сделку */
  restoreTrade(date: string, trade: Trade, index: number) {
    const d = this.day(date);
    if (d.trades.some((t) => t.id === trade.id)) return;
    const trades = [...d.trades];
    trades.splice(clamp(index, 0, trades.length), 0, trade);
    const doc: DayDoc = { marks: d.marks, trades };
    if (!this.guardSize(doc)) return;
    this.commitDay(date, doc);
    haptic.select();
    this.toast('success', 'Сделка восстановлена');
  }

  // ── Импорт / сброс ─────────────────────────────────────────────────────

  async replaceAll(days: Record<string, DayDoc>, meta?: Partial<Meta>) {
    const prevDays = this.state.days;
    const prevMeta = this.state.meta;
    const m: Meta = { ...prevMeta, ...meta, version: 1 };

    const cleanDays: Record<string, DayDoc> = {};
    let skipped = 0;
    for (const date of Object.keys(days)) {
      if (!DATE_RE.test(date)) continue;
      if (JSON.stringify(days[date]).length > S.VALUE_LIMIT) {
        skipped += 1;
        continue;
      }
      cleanDays[date] = days[date];
    }
    const newDates = Object.keys(cleanDays).sort();
    const idxJson = JSON.stringify(newDates);
    if (idxJson.length > S.VALUE_LIMIT) {
      this.toast('error', 'Слишком много дней для индекса хранилища — импорт отменён');
      return;
    }

    // Что уже записано в хранилище — чтобы при сбое вернуть всё как было
    const overwritten: string[] = []; // даты, которые были и перезаписаны
    const created: string[] = []; // даты, которых раньше не было
    let idxWritten = false;
    let metaWritten = false;

    try {
      // 1) Сначала пишем новые документы дней: старые индекс и мета пока не тронуты
      for (const date of newDates) {
        (date in prevDays ? overwritten : created).push(date);
        await S.storageSet(dayKey(date), JSON.stringify(cleanDays[date]));
      }
      // 2) Индекс и мета — момент «переключения» на новые данные
      idxWritten = true;
      await S.storageSet(K_IDX, idxJson);
      metaWritten = true;
      await S.storageSet(K_META, JSON.stringify(m));
    } catch (e) {
      console.error(e);
      // Откат: возвращаем перезаписанные дни, убираем созданные, восстанавливаем индекс и мету
      let restored = true;
      try {
        for (const d of overwritten) await S.storageSet(dayKey(d), JSON.stringify(prevDays[d]));
        await S.storageRemove(created.map(dayKey));
        if (idxWritten) await S.storageSet(K_IDX, JSON.stringify(Object.keys(prevDays).sort()));
        if (metaWritten) await S.storageSet(K_META, JSON.stringify(prevMeta));
      } catch (e2) {
        console.error(e2);
        restored = false;
      }
      haptic.error();
      this.toast(
        'error',
        restored
          ? 'Ошибка импорта — данные не изменены'
          : 'Ошибка импорта — часть данных могла измениться. Перезапустите приложение и проверьте журнал',
        undefined,
        restored ? undefined : 8000
      );
      return;
    }

    // 3) Всё записано — переключаем состояние и убираем дни, которых нет в импорте
    this.lastIdxJson = idxJson;
    this.set({ days: cleanDays, meta: m });
    haptic.success();
    this.toast('success', `Импортировано дней: ${newDates.length}${skipped ? `, пропущено переполненных: ${skipped}` : ''}`);

    const stale = Object.keys(prevDays)
      .filter((d) => !(d in cleanDays))
      .map(dayKey);
    try {
      await S.storageRemove(stale);
    } catch (e) {
      console.error(e); // осиротевшие ключи вне индекса на журнал не влияют
    }
  }

  async resetAll() {
    try {
      const keys = [K_IDX, ...Object.keys(this.state.days).map(dayKey)];
      await S.storageRemove(keys);
      const meta: Meta = { ...defaultMeta(), bioLock: this.state.meta.bioLock };
      await S.storageSet(K_META, JSON.stringify(meta));
      this.lastIdxJson = '';
      this.set({ days: {}, meta });
      haptic.warn();
      this.toast('info', 'Все данные удалены');
    } catch {
      this.toast('error', 'Ошибка сброса хранилища');
    }
  }
}

export const store = new Store();
export const useJournal = () => useSyncExternalStore(store.subscribe, store.get);
