// ─────────────────────────────────────────────────────────────────────────────
// Расчёты прогресса. Чистые функции, без побочных эффектов.
// ─────────────────────────────────────────────────────────────────────────────
import type { DayDoc, Mark, Meta } from './types';

// Ключи CloudStorage
export const K_META = 'meta';
export const K_IDX = 'idx:days';
export const dayKey = (date: string) => `d:${date}`;
export const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

// ── Числа ────────────────────────────────────────────────────────────────────

export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
export const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v));

/** Парсинг «12,5» / «12.5» / «-3» → number | null */
export function parseNum(raw: string): number | null {
  const s = raw.trim().replace(',', '.').replace('−', '-');
  if (s === '' || s === '-' || s === '.') return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

// ── Прогресс ─────────────────────────────────────────────────────────────────

/** dayProgress(date) = сумма pct всех Mark за дату, где checked === true */
export function dayProgress(doc?: DayDoc | Mark[]): number {
  const marks: Mark[] = Array.isArray(doc) ? doc : doc?.marks ?? [];
  return round2(marks.filter((m) => m.checked).reduce((s, m) => s + m.pct, 0));
}

/** Сумма кусков, которые НЕ учитываются (галочка снята) — для подсказки в UI */
export function dayUncheckedSum(doc?: DayDoc): number {
  return round2((doc?.marks ?? []).filter((m) => !m.checked).reduce((s, m) => s + m.pct, 0));
}

/** День закрыт, если засчитанный прогресс >= цели дня (по умолчанию +20%) */
export const isDayClosed = (progress: number, target: number) => progress >= target;

// ── Статистика цели ──────────────────────────────────────────────────────────

export type Stats = {
  closed: number; // сколько дней закрыто (цель: N/40)
  total: number; // всего дней с данными
  streak: number; // текущая серия закрытых дней подряд
  best: { date: string; pct: number } | null; // лучший день по засчитанной сумме
};

export function computeStats(days: Record<string, DayDoc>, meta: Meta): Stats {
  const closedDates = new Set<string>();
  let best: Stats['best'] = null;

  for (const date of Object.keys(days)) {
    const p = dayProgress(days[date]);
    // 1 день = максимум 1 закрытие: Set дат, излишек никуда не переносится
    if (isDayClosed(p, meta.dayTargetPct)) closedDates.add(date);
    if (days[date].marks.length > 0 && (!best || p > best.pct)) best = { date, pct: p };
  }

  // Серия: идём назад по календарю от сегодня (если сегодня не закрыт — от вчера)
  let cursor = todayISO();
  if (!closedDates.has(cursor)) cursor = addDays(cursor, -1);
  let streak = 0;
  while (closedDates.has(cursor)) {
    streak += 1;
    cursor = addDays(cursor, -1);
  }

  return { closed: closedDates.size, total: Object.keys(days).length, streak, best };
}

// ── Даты ─────────────────────────────────────────────────────────────────────

const pad2 = (n: number) => String(n).padStart(2, '0');
export const toISO = (d: Date) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
export const todayISO = () => toISO(new Date());

export function addDays(iso: string, delta: number): string {
  const d = new Date(`${iso}T00:00:00`);
  d.setDate(d.getDate() + delta);
  return toISO(d);
}

const wdShort = new Intl.DateTimeFormat('ru-RU', { weekday: 'short' });
const dayMonth = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long' });
const fullDay = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });

const at = (iso: string) => new Date(`${iso}T00:00:00`);
export const fmtWeekday = (iso: string) => wdShort.format(at(iso));
export const fmtDayMonth = (iso: string) => dayMonth.format(at(iso));
export const fmtFullDate = (iso: string) => fullDay.format(at(iso));
export const fmtTs = (ts: number) => fullDay.format(new Date(ts));

/** «Сегодня» / «Вчера» / «Завтра» или null */
export function relDay(iso: string): string | null {
  const t = todayISO();
  if (iso === t) return 'Сегодня';
  if (iso === addDays(t, -1)) return 'Вчера';
  if (iso === addDays(t, 1)) return 'Завтра';
  return null;
}

// ── Форматирование процентов ────────────────────────────────────────────────

const nf = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 });

/** fmtPct(12.5) → «+12,5%»; fmtPct(-3) → «−3%»; fmtPct(0) → «0%» */
export function fmtPct(v: number, forceSign = true): string {
  const sign = v > 0 ? '+' : v < 0 ? '−' : forceSign ? '+' : '';
  return `${sign}${nf.format(Math.abs(v))}%`;
}

export const fmtPlain = (v: number) => nf.format(v);

// ── ID ───────────────────────────────────────────────────────────────────────

export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 9);

// ── Самопроверка (dev, консоль) — проверочные кейсы из ТЗ ───────────────────

export function selfTest() {
  const mk = (pct: number, checked: boolean): Mark => ({
    id: uid(),
    date: '2026-01-01',
    pct,
    checked,
    createdAt: 1,
  });
  const T = 20;
  const cases: Array<[string, boolean]> = [
    // +10✅ и +10✅ за одну дату → день закрыт (20/20), цель 1/40
    ['+10✅ +10✅ → закрыт', isDayClosed(dayProgress([mk(10, true), mk(10, true)]), T)],
    // +10✅ и +10☐ → день НЕ закрыт, прогресс 10/20
    ['+10✅ +10☐ → 10/20 не закрыт', dayProgress([mk(10, true), mk(10, false)]) === 10 && !isDayClosed(10, T)],
    // +35✅ → день закрыт, цель +1 (излишек не переносится)
    ['+35✅ → закрыт', isDayClosed(dayProgress([mk(35, true)]), T)],
    // излишек не переносится: +35 за дату → всё равно ровно 1 закрытый день
    [
      '+35✅ → ровно 1/40',
      computeStats({ '2026-01-01': { marks: [mk(35, true)], trades: [] } }, { version: 1, goalDays: 40, dayTargetPct: 20, createdAt: 0 }).closed === 1,
    ],
    // отрицательный прогресс разрешён
    ['+25✅ −10✅ → 15/20 не закрыт', dayProgress([mk(25, true), mk(-10, true)]) === 15 && !isDayClosed(15, T)],
    // снятие галочки выключает кусок из прогресса
    ['снятие ✅ → вычитается', dayProgress([mk(20, true), mk(5, false)]) === 20],
    // капитал не уходит в минус: день хуже −100% обнуляет депозит, следующие дни его не «переворачивают»
    [
      '−150✅ → капитал 0, а не минус',
      currentCapital(
        { '2026-01-01': { marks: [mk(-150, true)], trades: [] }, '2026-01-02': { marks: [mk(20, true)], trades: [] } },
        1000
      ) === 0,
    ],
  ];
  const failed = cases.filter(([, ok]) => !ok);
  // eslint-disable-next-line no-console
  console.table(cases.map(([name, ok]) => ({ кейс: name, результат: ok ? 'PASS' : 'FAIL' })));
  if (failed.length) console.error('TJ selftest failed:', failed.map(([n]) => n));
}

// ── Калькулятор капитала (сложный процент) ───────────────────────────────────

/** Текущий капитал: стартовый, прошитый через засчитанный прогресс каждого дня */
export function currentCapital(days: Record<string, DayDoc>, start: number): number {
  let cap = start;
  for (const date of Object.keys(days).sort()) {
    if (days[date].marks.length === 0) continue;
    // день хуже −100% обнуляет депозит; множитель не должен менять знак капитала
    cap *= Math.max(0, 1 + dayProgress(days[date]) / 100);
  }
  return round2(cap);
}

/** base × (1 + rate%)^periods */
export function compound(base: number, ratePct: number, periods: number): number {
  return base * Math.pow(1 + ratePct / 100, periods);
}

/** Сколько периодов по rate% нужно, чтобы из from получить to (ceil). null — недостижимо */
export function daysToReach(from: number, to: number, ratePct: number): number | null {
  if (from <= 0 || ratePct <= 0) return null;
  if (to <= from) return 0;
  return Math.ceil(Math.log(to / from) / Math.log(1 + ratePct / 100));
}

/** Форматирование денег: 12345.6 → «12 346 $» */
export function fmtMoney(v: number, cur = '$'): string {
  if (!Number.isFinite(v)) return '—';
  const abs = Math.abs(v);
  const digits = abs >= 10_000 ? 0 : abs >= 100 ? 1 : 2;
  const nf = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: digits });
  return `${nf.format(v)} ${cur}`;
}
