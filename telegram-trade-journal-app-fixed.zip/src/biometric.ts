// ─────────────────────────────────────────────────────────────────────────────
// BiometricManager Telegram (Bot API 7.2+): опциональная биометрическая
// защита входа. Вне Telegram или без биометрии — все функции мягко отказывают.
// ─────────────────────────────────────────────────────────────────────────────
import { inTg, tg } from './telegram';

export const bioSupported = () => inTg() && Boolean(tg()?.BiometricManager);

function withFallback<T>(p: Promise<T>, ms: number, fallback: T): Promise<T> {
  return Promise.race([p, new Promise<T>((res) => window.setTimeout(() => res(fallback), ms))]);
}

/** Инициализация менеджера; resolve = доступна ли биометрия на устройстве */
export function bioInit(): Promise<boolean> {
  const bm = tg()?.BiometricManager;
  if (!bioSupported() || !bm) return Promise.resolve(false);
  return withFallback(
    new Promise<boolean>((resolve) => {
      try {
        bm.init(() => resolve(Boolean(bm.isBiometricAvailable)));
      } catch {
        resolve(false);
      }
    }),
    2500,
    false
  );
}

/** Запрос доступа к биометрии у пользователя */
export function bioRequestAccess(reason: string): Promise<boolean> {
  const bm = tg()?.BiometricManager;
  if (!bioSupported() || !bm) return Promise.resolve(false);
  return withFallback(
    new Promise<boolean>((resolve) => {
      try {
        bm.requestAccess({ reason }, (granted) => resolve(Boolean(granted)));
      } catch {
        resolve(false);
      }
    }),
    30000,
    false
  );
}

/** Аутентификация по Face ID / отпечатку */
export function bioAuthenticate(reason = 'Доступ к журналу трейдера'): Promise<boolean> {
  const bm = tg()?.BiometricManager;
  if (!bioSupported() || !bm) return Promise.resolve(false);
  return withFallback(
    new Promise<boolean>((resolve) => {
      try {
        bm.authenticate({ reason }, (ok) => resolve(Boolean(ok)));
      } catch {
        resolve(false);
      }
    }),
    60000,
    false
  );
}
