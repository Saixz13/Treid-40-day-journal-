// ─────────────────────────────────────────────────────────────────────────────
// Trade Journal 40×20% — модель данных
// ─────────────────────────────────────────────────────────────────────────────

/** Счётный кусок (единственное, что влияет на прогресс) */
export type Mark = {
  id: string;
  date: string; // YYYY-MM-DD
  pct: number; // может быть и «+», и «−»
  note?: string;
  checked: boolean; // ✅ учитывать в прогрессе
  createdAt: number;
};

/** Лог сделки (НЕ влияет на прогресс — только история/заметки) */
export type Trade = {
  id: string;
  date: string;
  symbol?: string;
  side?: 'long' | 'short';
  setup?: string;
  riskPct?: number;
  resultPct?: number;
  note?: string;
  createdAt: number;
};

/** Документ дня — хранится по ключу d:YYYY-MM-DD */
export type DayDoc = {
  marks: Mark[];
  trades: Trade[];
};

/** Мета — хранится по ключу meta */
export type Meta = {
  version: number;
  goalDays: number; // цель: 40 дней
  dayTargetPct: number; // закрытие дня: +20%
  createdAt: number;
  bioLock?: boolean; // биометрическая защита входа (Telegram)
  startCapital?: number; // начальный капитал (калькулятор депозита)
  currency?: string; // валюта отображения: $, €, ₽, USDT…
};

export const defaultMeta = (): Meta => ({
  version: 1,
  goalDays: 40,
  dayTargetPct: 20,
  createdAt: Date.now(),
});

/** Экспортируемый снимок всех данных */
export type ExportPayload = {
  app: 'trade-journal-40x20';
  version: number;
  exportedAt: string;
  meta: Meta;
  days: Record<string, DayDoc>;
};

// ── UI-типы ─────────────────────────────────────────────────────────────────

export type Tab = 'day' | 'history' | 'data';

export type DialogState =
  | { kind: 'mark-add'; date: string }
  | { kind: 'mark-edit'; date: string; mark: Mark }
  | { kind: 'trade-add'; date: string }
  | { kind: 'import' }
  | { kind: 'share' }
  | { kind: 'capital' }
  | {
      kind: 'confirm';
      title: string;
      body?: string;
      confirmText: string;
      danger?: boolean;
      onConfirm: () => void;
    };
