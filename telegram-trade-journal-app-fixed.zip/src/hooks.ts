// ─────────────────────────────────────────────────────────────────────────────
// UI-хуки. useSpringNumber — «пружинная» анимация числа через rAF.
// ─────────────────────────────────────────────────────────────────────────────
import { useEffect, useRef, useState } from 'react';

export function useSpringNumber(target: number, stiffness = 160, damping = 20): number {
  const [value, setValue] = useState(target);
  const sim = useRef({ v: target, vel: 0, raf: 0 });

  useEffect(() => {
    const s = sim.current;
    if (s.v === target) return;
    cancelAnimationFrame(s.raf);
    let last = performance.now();

    const step = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const force = -stiffness * (s.v - target) - damping * s.vel;
      s.vel += force * dt;
      s.v += s.vel * dt;
      if (Math.abs(s.v - target) < 0.004 && Math.abs(s.vel) < 0.004) {
        s.v = target;
        s.vel = 0;
        setValue(target);
        return;
      }
      setValue(s.v);
      s.raf = requestAnimationFrame(step);
    };
    s.raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(s.raf);
  }, [target, stiffness, damping]);

  return value;
}
