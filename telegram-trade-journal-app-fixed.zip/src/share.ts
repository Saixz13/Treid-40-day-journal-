// ─────────────────────────────────────────────────────────────────────────────
// Генератор share-карточки прогресса: Canvas 2D → PNG (1080×1350).
// Всё рисуется локально на устройстве — данные никуда не отправляются.
// ─────────────────────────────────────────────────────────────────────────────
import { computeStats, fmtDayMonth, fmtPct, todayISO } from './calc';
import { store } from './store';

export type ShareImage = { dataUrl: string; blob: Blob };

const W = 1080;
const H = 1350;

function roundRectPath(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawPill(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  value: string,
  label: string,
  color: string
) {
  roundRectPath(ctx, x, y, w, h, 32);
  ctx.fillStyle = 'rgba(255,255,255,0.045)';
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.1)';
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = color;
  ctx.font = '700 52px "Space Grotesk", Inter, system-ui, sans-serif';
  ctx.fillText(value, x + w / 2, y + h / 2 - 16);
  ctx.fillStyle = '#8B95A5';
  ctx.font = '500 26px Inter, system-ui, sans-serif';
  ctx.fillText(label, x + w / 2, y + h / 2 + 36);
}

export async function renderShareCard(): Promise<ShareImage> {
  const st = store.get();
  const stats = computeStats(st.days, st.meta);
  const goal = st.meta.goalDays;
  const closed = stats.closed;
  const frac = Math.min(1, closed / goal);

  try {
    await Promise.all([
      document.fonts.load('700 150px "Space Grotesk"'),
      document.fonts.load('700 52px "Space Grotesk"'),
      document.fonts.load('500 30px "Inter"'),
    ]);
  } catch {
    /* упадёт на системные шрифты — не страшно */
  }

  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D не поддерживается');

  // ── Фон и свечение
  ctx.fillStyle = '#0B0E14';
  ctx.fillRect(0, 0, W, H);
  const glow = ctx.createRadialGradient(W / 2, -160, 60, W / 2, -160, 780);
  glow.addColorStop(0, 'rgba(46,230,166,0.32)');
  glow.addColorStop(1, 'rgba(46,230,166,0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, W, H);

  // ── Сетка
  ctx.strokeStyle = 'rgba(255,255,255,0.035)';
  ctx.lineWidth = 2;
  for (let x = 0; x <= W; x += 90) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, H);
    ctx.stroke();
  }
  for (let y = 0; y <= H; y += 90) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(W, y);
    ctx.stroke();
  }

  const grad = ctx.createLinearGradient(0, 0, W, H);
  grad.addColorStop(0, '#8CF7CD');
  grad.addColorStop(1, '#2EE6A6');

  // ── Бренд: мини-кольцо + название
  ctx.strokeStyle = grad;
  ctx.lineWidth = 12;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(150, 154, 34, -0.5 * Math.PI, 1.15 * Math.PI);
  ctx.stroke();
  ctx.fillStyle = '#2EE6A6';
  ctx.beginPath();
  ctx.arc(150, 154, 10, 0, Math.PI * 2);
  ctx.fill();

  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#EDF2F9';
  ctx.font = '600 36px Inter, system-ui, sans-serif';
  ctx.fillText('TRADE JOURNAL', 210, 142);
  ctx.fillStyle = '#8B95A5';
  ctx.font = '500 28px Inter, system-ui, sans-serif';
  ctx.fillText(`цель — ${goal} дней × +${st.meta.dayTargetPct}%`, 210, 188);

  // ── Главное кольцо цели
  const cx = W / 2;
  const cy = 540;
  const R = 205;
  const SW = 46;
  ctx.strokeStyle = 'rgba(255,255,255,0.07)';
  ctx.lineWidth = SW;
  ctx.lineCap = 'butt';
  ctx.beginPath();
  ctx.arc(cx, cy, R, 0, Math.PI * 2);
  ctx.stroke();
  ctx.strokeStyle = grad;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(cx, cy, R, -Math.PI / 2, -Math.PI / 2 + frac * Math.PI * 2);
  ctx.stroke();

  ctx.textAlign = 'center';
  ctx.fillStyle = '#EDF2F9';
  ctx.font = '700 150px "Space Grotesk", Inter, system-ui, sans-serif';
  ctx.fillText(`${closed}/${goal}`, cx, cy + 2);
  ctx.fillStyle = '#8B95A5';
  ctx.font = '500 34px Inter, system-ui, sans-serif';
  ctx.fillText('дней закрыто', cx, cy + 96);

  // ── Пилюли статистики
  const pillW = 304;
  const gap = 24;
  const startX = (W - pillW * 3 - gap * 2) / 2;
  const pillY = 880;
  drawPill(ctx, startX, pillY, pillW, 172, `${stats.streak}`, 'серия подряд', '#FFB224');
  drawPill(
    ctx,
    startX + pillW + gap,
    pillY,
    pillW,
    172,
    stats.best ? fmtPct(stats.best.pct) : '—',
    'лучший день',
    '#6EA8FF'
  );
  drawPill(
    ctx,
    startX + (pillW + gap) * 2,
    pillY,
    pillW,
    172,
    `${Math.round(frac * 100)}%`,
    'цели выполнено',
    '#2EE6A6'
  );

  // ── Рамка и футер
  roundRectPath(ctx, 30, 30, W - 60, H - 60, 48);
  ctx.strokeStyle = 'rgba(255,255,255,0.09)';
  ctx.lineWidth = 3;
  ctx.stroke();

  ctx.fillStyle = '#5C6675';
  ctx.font = '500 27px Inter, system-ui, sans-serif';
  ctx.fillText(`${fmtDayMonth(todayISO())} · закрывай день за +20%`, cx, H - 96);

  const blob = await new Promise<Blob>((res, rej) =>
    canvas.toBlob((b) => (b ? res(b) : rej(new Error('toBlob failed'))), 'image/png')
  );
  return { dataUrl: canvas.toDataURL('image/png'), blob };
}
