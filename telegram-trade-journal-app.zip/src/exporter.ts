// ─────────────────────────────────────────────────────────────────────────────
// Экспорт (JSON/CSV) и импорт (JSON) данных журнала.
// ─────────────────────────────────────────────────────────────────────────────
import type { DayDoc, ExportPayload, Mark, Meta, Trade } from './types';
import { DATE_RE, round2, todayISO, uid } from './calc';

export function buildJSON(meta: Meta, days: Record<string, DayDoc>): string {
  const payload: ExportPayload = {
    app: 'trade-journal-40x20',
    version: 1,
    exportedAt: new Date().toISOString(),
    meta,
    days,
  };
  return JSON.stringify(payload, null, 2);
}

export function buildCSV(days: Record<string, DayDoc>): string {
  const esc = (v: unknown) => {
    const s = v === undefined || v === null ? '' : String(v);
    return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const rows: string[] = ['kind;date;pct;checked;note;symbol;side;setup;risk_pct;result_pct;created_at'];
  for (const date of Object.keys(days).sort()) {
    const d = days[date];
    for (const m of d.marks) {
      rows.push(
        ['mark', m.date, String(m.pct).replace('.', ','), m.checked ? 1 : 0, m.note ?? '', '', '', '', '', '', new Date(m.createdAt).toISOString()]
          .map(esc)
          .join(';')
      );
    }
    for (const t of d.trades) {
      rows.push(
        [
          'trade',
          t.date,
          '',
          '',
          t.note ?? '',
          t.symbol ?? '',
          t.side ?? '',
          t.setup ?? '',
          t.riskPct ?? '',
          t.resultPct ?? '',
          new Date(t.createdAt).toISOString(),
        ]
          .map(esc)
          .join(';')
      );
    }
  }
  return rows.join('\n');
}

export const exportFileName = (ext: 'json' | 'csv') => `trade-journal-40x20-${todayISO()}.${ext}`;

// ── Импорт ───────────────────────────────────────────────────────────────────

export type ParsedImport = {
  days: Record<string, DayDoc>;
  meta?: Partial<Meta>;
  counts: { days: number; marks: number; trades: number };
};

export function parseImport(text: string): ParsedImport {
  let raw: unknown;
  try {
    // strip BOM (U+FEFF) — встречается у файлов из некоторых редакторов
    raw = JSON.parse(text.replace(/^\uFEFF/, '').trim());
  } catch {
    throw new Error('Это не валидный JSON');
  }
  const obj = raw as Record<string, unknown>;
  const srcDays = (obj?.days ?? (obj?.data as Record<string, unknown> | undefined)?.days) as
    | Record<string, unknown>
    | undefined;
  if (!srcDays || typeof srcDays !== 'object') throw new Error('Не найден блок «days» — формат не распознан');

  const days: Record<string, DayDoc> = {};
  let marksCount = 0;
  let tradesCount = 0;

  for (const [date, docRaw] of Object.entries(srcDays)) {
    if (!DATE_RE.test(date)) continue;
    const doc = docRaw as { marks?: unknown[]; trades?: unknown[] };

    const marks: Mark[] = (Array.isArray(doc?.marks) ? doc.marks : [])
      .map((m): Mark => {
        const mm = m as Partial<Mark>;
        return {
          id: typeof mm.id === 'string' ? mm.id : uid(),
          date,
          pct: round2(Number(mm.pct) || 0),
          note: typeof mm.note === 'string' ? mm.note : undefined,
          checked: mm.checked !== false, // по умолчанию — учитывается
          createdAt: Number(mm.createdAt) || Date.now(),
        };
      })
      .filter((m) => m.pct !== 0);

    const trades: Trade[] = (Array.isArray(doc?.trades) ? doc.trades : []).map((t): Trade => {
      const tt = t as Partial<Trade>;
      const num = (v: unknown) => (v === undefined || v === null || v === '' || !Number.isFinite(Number(v)) ? undefined : Number(v));
      return {
        id: typeof tt.id === 'string' ? tt.id : uid(),
        date,
        symbol: typeof tt.symbol === 'string' && tt.symbol ? tt.symbol : undefined,
        side: tt.side === 'long' || tt.side === 'short' ? tt.side : undefined,
        setup: typeof tt.setup === 'string' && tt.setup ? tt.setup : undefined,
        riskPct: num(tt.riskPct),
        resultPct: num(tt.resultPct),
        note: typeof tt.note === 'string' ? tt.note : undefined,
        createdAt: Number(tt.createdAt) || Date.now(),
      };
    });

    if (marks.length || trades.length) {
      days[date] = { marks, trades };
      marksCount += marks.length;
      tradesCount += trades.length;
    }
  }

  if (Object.keys(days).length === 0) throw new Error('В файле нет ни одной записи');

  const metaRaw = obj?.meta as Partial<Meta> | undefined;
  const meta =
    metaRaw && typeof metaRaw === 'object'
      ? {
          goalDays: Number(metaRaw.goalDays) || 40,
          dayTargetPct: Number(metaRaw.dayTargetPct) || 20,
        }
      : undefined;

  return { days, meta, counts: { days: Object.keys(days).length, marks: marksCount, trades: tradesCount } };
}

// ── Буфер обмена и скачивание ───────────────────────────────────────────────

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      const ok = document.execCommand('copy');
      ta.remove();
      return ok;
    } catch {
      return false;
    }
  }
}

export function downloadFile(name: string, content: string, mime: string) {
  // BOM нужен Excel для CSV, но ломает JSON.parse при обратном импорте
  const prefix = mime.startsWith('text/csv') ? '\ufeff' : '';
  const blob = new Blob([prefix + content], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}
