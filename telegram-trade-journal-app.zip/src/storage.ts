// ─────────────────────────────────────────────────────────────────────────────
// Хранение данных: Telegram CloudStorage → fallback на localStorage.
// Схема ключей:
//   meta          — { goalDays, dayTargetPct, createdAt, version }
//   idx:days      — JSON-массив дат, по которым есть данные
//   d:YYYY-MM-DD  — JSON документа дня { marks: [...], trades: [...] }
// Лимит CloudStorage: значение ≈ 4096 символов → держим запас VALUE_LIMIT.
// ─────────────────────────────────────────────────────────────────────────────
import { getCloudStorage } from './telegram';

export type Backend = 'cloud' | 'local';

const LS_PREFIX = 'tj40:';
/** Безопасный лимит на одно значение (с запасом от 4096) */
export const VALUE_LIMIT = 3900;

let backendCache: Backend | null = null;

export const backend = (): Backend => backendCache ?? 'local';

/** Один раз определяем доступность CloudStorage (пробуем getKeys) */
export async function detectBackend(): Promise<Backend> {
  if (backendCache) return backendCache;
  const cs = getCloudStorage();
  if (!cs) {
    backendCache = 'local';
    return backendCache;
  }
  const ok = await new Promise<boolean>((resolve) => {
    const timer = window.setTimeout(() => resolve(false), 1200);
    try {
      cs.getKeys((err) => {
        window.clearTimeout(timer);
        resolve(!err);
      });
    } catch {
      window.clearTimeout(timer);
      resolve(false);
    }
  });
  backendCache = ok ? 'cloud' : 'local';
  return backendCache;
}

/** CloudStorage, только если он реально подтверждён detectBackend() */
const activeCloud = () => (backendCache === 'cloud' ? getCloudStorage() : null);

function withTimeout<T>(p: Promise<T>, ms = 3000): Promise<T> {
  return Promise.race([p, new Promise<T>((_, rej) => window.setTimeout(() => rej(new Error('storage timeout')), ms))]);
}

export async function storageSet(key: string, value: string): Promise<void> {
  const cs = activeCloud();
  if (!cs) {
    localStorage.setItem(LS_PREFIX + key, value);
    return;
  }
  await withTimeout(
    new Promise<void>((res, rej) => {
      try {
        cs.setItem(key, value, (err) => (err ? rej(new Error(err)) : res()));
      } catch (e) {
        rej(e as Error);
      }
    })
  );
}

/** Пакетное чтение (CloudStorage умеет массив ключей за один вызов) */
export async function storageGetMany(keys: string[]): Promise<Record<string, string | null>> {
  const out: Record<string, string | null> = {};
  if (keys.length === 0) return out;
  const cs = activeCloud();
  if (!cs) {
    for (const k of keys) {
      const v = localStorage.getItem(LS_PREFIX + k);
      out[k] = v && v !== '' ? v : null;
    }
    return out;
  }
  const values = await withTimeout(
    new Promise<unknown>((res, rej) => {
      try {
        cs.getItem(keys, (err, value) => (err ? rej(new Error(err)) : res(value)));
      } catch (e) {
        rej(e as Error);
      }
    })
  );
  const map = (values ?? {}) as Record<string, string>;
  for (const k of keys) {
    const v = map[k];
    out[k] = typeof v === 'string' && v !== '' ? v : null;
  }
  return out;
}

export async function storageRemove(keys: string[]): Promise<void> {
  if (keys.length === 0) return;
  const cs = activeCloud();
  if (!cs) {
    for (const k of keys) localStorage.removeItem(LS_PREFIX + k);
    return;
  }
  await withTimeout(
    new Promise<void>((res, rej) => {
      try {
        cs.removeItem(keys, (err) => (err ? rej(new Error(err)) : res()));
      } catch (e) {
        rej(e as Error);
      }
    })
  );
}
