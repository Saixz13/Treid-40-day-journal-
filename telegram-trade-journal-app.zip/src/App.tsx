import { useEffect, useMemo, useState } from 'react';
import { Target } from 'lucide-react';
import type { DialogState, Tab } from './types';
import { store, useJournal } from './store';
import { applyTelegramTheme, bb, initTelegram, tg } from './telegram';
import { bioAuthenticate, bioInit, bioSupported } from './biometric';
import { computeStats, selfTest, todayISO } from './calc';
import { TabBar } from './components/TabBar';
import { Toasts } from './components/Toasts';
import { LockScreen } from './components/LockScreen';
import { ConfirmDialog, ImportDialog, PctDialog, TradeDialog } from './components/dialogs';
import { ShareDialog } from './components/ShareDialog';
import { CapitalDialog } from './components/CapitalDialog';
import { DayScreen } from './screens/DayScreen';
import { HistoryScreen } from './screens/HistoryScreen';
import { DataScreen } from './screens/DataScreen';

export default function App() {
  const st = useJournal();
  const [tab, setTab] = useState<Tab>('day');
  const [date, setDate] = useState(todayISO());
  const [dialog, setDialog] = useState<DialogState | null>(null);
  const [locked, setLocked] = useState(false);

  // Инициализация Telegram + загрузка хранилища
  useEffect(() => {
    initTelegram();
    applyTelegramTheme();
    void store.load();
    if (import.meta.env.DEV) selfTest();
    const t = tg();
    const onTheme = () => applyTelegramTheme();
    try {
      t?.onEvent('themeChanged', onTheme);
    } catch {
      /* noop */
    }
    return () => {
      try {
        t?.offEvent?.('themeChanged', onTheme);
      } catch {
        /* noop */
      }
    };
  }, []);

  // Биометрический гейт: если включён bioLock — требуем подтверждение при входе
  useEffect(() => {
    if (!st.ready || !st.meta.bioLock || locked) return;
    let cancelled = false;
    void (async () => {
      if (!bioSupported()) return;
      const available = await bioInit();
      if (cancelled || !available) return; // биометрии нет — не блокируем
      setLocked(true);
      const ok = await bioAuthenticate('Доступ к Trade Journal 40×20%');
      if (!cancelled && ok) setLocked(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [st.ready, st.meta.bioLock, locked]);

  // BackButton: закрывает диалог → возвращает на «День» → скрыт
  useEffect(() => {
    bb.set(dialog ? () => setDialog(null) : tab !== 'day' ? () => setTab('day') : null);
  }, [tab, dialog]);

  const stats = useMemo(() => computeStats(st.days, st.meta), [st.days, st.meta]);

  if (!st.ready) {
    return (
      <div className="splash">
        <div className="splash-logo num">40×20%</div>
        <div className="splash-sub">TRADE JOURNAL</div>
      </div>
    );
  }

  if (locked) {
    return (
      <>
        <LockScreen onUnlocked={() => setLocked(false)} />
        <Toasts />
      </>
    );
  }

  return (
    <div className="app">
      <div className="app-glow" />

      <header className="app-header">
        <div className="brand">
          <div className="brand-mark">
            <Target size={18} strokeWidth={2.4} />
          </div>
          <div className="brand-text">
            <div className="brand-name">Trade Journal</div>
            <div className="brand-sub">40 дней × +20%</div>
          </div>
        </div>
        <div className="goal-chip num" title="Закрыто дней">
          {stats.closed}
          <span>/{st.meta.goalDays}</span>
        </div>
      </header>

      <main className="content">
        <div key={tab} className="screen-wrap">
          {tab === 'day' && <DayScreen date={date} onDate={setDate} openDialog={setDialog} />}
          {tab === 'history' && (
            <HistoryScreen
              onOpenDay={(d) => {
                setDate(d);
                setTab('day');
              }}
            />
          )}
          {tab === 'data' && <DataScreen openDialog={setDialog} />}
        </div>
      </main>

      <TabBar tab={tab} onChange={setTab} />
      <Toasts />

      {dialog?.kind === 'mark-add' && <PctDialog date={dialog.date} onClose={() => setDialog(null)} />}
      {dialog?.kind === 'mark-edit' && <PctDialog date={dialog.date} mark={dialog.mark} onClose={() => setDialog(null)} />}
      {dialog?.kind === 'trade-add' && <TradeDialog date={dialog.date} onClose={() => setDialog(null)} />}
      {dialog?.kind === 'import' && <ImportDialog onClose={() => setDialog(null)} />}
      {dialog?.kind === 'share' && <ShareDialog onClose={() => setDialog(null)} />}
      {dialog?.kind === 'capital' && <CapitalDialog onClose={() => setDialog(null)} />}
      {dialog?.kind === 'confirm' && (
        <ConfirmDialog
          title={dialog.title}
          body={dialog.body}
          confirmText={dialog.confirmText}
          danger={dialog.danger}
          onConfirm={dialog.onConfirm}
          onClose={() => setDialog(null)}
        />
      )}
    </div>
  );
}
